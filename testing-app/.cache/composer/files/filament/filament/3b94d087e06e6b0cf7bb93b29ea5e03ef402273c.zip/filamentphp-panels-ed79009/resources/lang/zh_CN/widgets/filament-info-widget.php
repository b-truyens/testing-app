<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => '文档',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
