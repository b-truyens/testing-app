<?php

return [

    'single' => [

        'label' => 'संपादन',

        'modal' => [

            'heading' => ':label संपादित करें',

            'actions' => [

                'save' => [
                    'label' => 'सेव',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'सेव हो गया',
        ],

    ],

];
