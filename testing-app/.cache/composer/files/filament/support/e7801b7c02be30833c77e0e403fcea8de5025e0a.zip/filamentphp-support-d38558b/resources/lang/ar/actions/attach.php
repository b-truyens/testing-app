<?php

return [

    'single' => [

        'label' => 'إرفاق',

        'modal' => [

            'heading' => 'إرفاق :label',

            'fields' => [

                'record_id' => [
                    'label' => 'سجلات',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'إرفاق',
                ],

                'attach_another' => [
                    'label' => 'إرفاق وبدء إرفاق المزيد',
                ],

            ],

        ],

        'messages' => [
            'attached' => 'تم الإرفاق',
        ],

    ],

];
