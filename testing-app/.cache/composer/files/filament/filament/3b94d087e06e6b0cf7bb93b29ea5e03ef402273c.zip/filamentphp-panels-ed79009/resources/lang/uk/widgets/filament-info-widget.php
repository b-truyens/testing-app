<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Документація',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
