<?php

return [

    'access_controlled_by_private_ancestor' => '祖先分类 :category 设置为私有并控制对此类别的访问.',
    'actions' => '分类操作',
    'category' => '分类|分类',
    'confirm_nonempty_delete' => '是的，我想永久删除此分类及其中的所有内容',
    'create' => '创建分类',
    'created' => '分类已创建',
    'deleted' => '分类已删除|分类已删除',
    'disable_threads' => '禁用贴子',
    'enable_threads' => '启用贴子',
    'make_private' => '设为私有',
    'make_public' => '设为公开',
    'mark_read' => '将此类别中的贴子标记为已读',
    'marked_read' => ':category中的新/更新的贴子已被标记为已读',
    'restored' => '分类已恢复|分类已恢复',
    'subcategories' => '子分类',
    'threads_disabled' => '此分类中禁用了新贴子创建',
    'updated' => '分类已更新|分类已更新',

];
