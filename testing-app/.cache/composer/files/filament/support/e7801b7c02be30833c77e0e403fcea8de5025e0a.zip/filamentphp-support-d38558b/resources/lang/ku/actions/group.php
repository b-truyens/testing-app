<?php

return [

    'trigger' => [
        'label' => 'کارەکان',
    ],

];
