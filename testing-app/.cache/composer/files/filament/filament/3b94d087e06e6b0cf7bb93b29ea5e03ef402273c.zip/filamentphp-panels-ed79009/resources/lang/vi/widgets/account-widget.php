<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Đăng xuất',
        ],

    ],

    'welcome' => 'Chào, :user',

];
