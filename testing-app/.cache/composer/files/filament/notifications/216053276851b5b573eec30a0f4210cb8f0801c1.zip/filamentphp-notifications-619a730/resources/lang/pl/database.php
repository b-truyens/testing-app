<?php

return [

    'modal' => [

        'heading' => 'Powiadomienia',

        'buttons' => [

            'clear' => [
                'label' => 'Wyczyść',
            ],

            'mark_all_as_read' => [
                'label' => 'Oznacz wszystkie jako przeczytane',
            ],

        ],

        'empty' => [
            'heading' => 'Brak powiadomień',
            'description' => 'Zajrzyj ponownie później',
        ],

    ],

];
