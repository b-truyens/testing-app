<?php

return [

    'actions' => '回贴操作',
    'created' => '回贴已创建',
    'delete' => '删除回贴|删除回贴',
    'deleted' => '回贴已删除|回贴已删除',
    'edit' => '编辑回贴',
    'last' => '最新回贴',
    'perma_deleted' => '回贴被永久删除|回贴被永久删除',
    'post' => '回贴|回贴',
    'restore' => '恢复回贴|恢复回贴',
    'restored' => '回贴已恢复|回贴已恢复',
    'select_all' => '选择所有回贴',
    'updated' => '回贴已更新|回贴已更新',
    'view' => '查看回贴',
    'your_post' => '你的回贴',

];
