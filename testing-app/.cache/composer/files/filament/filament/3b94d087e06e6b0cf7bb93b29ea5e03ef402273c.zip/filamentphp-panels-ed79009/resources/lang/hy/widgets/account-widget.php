<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Դուրս գալ',
        ],

    ],

    'welcome' => 'Բարի գալուստ, :user',

];
