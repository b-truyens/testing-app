<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Déconnexion',
        ],

    ],

    'welcome' => 'Bonjour :user',

];
