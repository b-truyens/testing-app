<?php

return [

    'modal' => [

        'heading' => 'Hysbysiadau',

        'buttons' => [

            'clear' => [
                'label' => 'Clirio',
            ],

            'mark_all_as_read' => [
                'label' => 'Nodi pob un fel ‘wedi darllen’',
            ],

        ],

        'empty' => [
            'heading' => 'Dim hysbysiad yma',
            'description' => 'Gwiriwch eto nes ymlaen',
        ],

    ],

];
