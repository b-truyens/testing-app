<?php

return [

    'category_threads_enabled' => 'ต้องเปิดการเพิ่มหัวข้อใหม่ในหมวดหมู่นี้ก่อน',
    'category_has_no_threads' => 'ต้องไม่มีหัวข้อในหมวดหมู่นี้ก่อน',
    'category_is_empty' => 'หมวดหมู่นี้ต้องไม่มีข้อมูล',

];
