<?php

return [

    'single' => [

        'label' => 'افزودن',

        'modal' => [

            'heading' => 'افزودن :label',

            'fields' => [

                'record_id' => [
                    'label' => 'رکورد',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'افزودن',
                ],

                'attach_another' => [
                    'label' => 'افزودن و افزودن یکی دیگر',
                ],

            ],

        ],

        'messages' => [
            'attached' => 'افزوده شد',
        ],

    ],

];
