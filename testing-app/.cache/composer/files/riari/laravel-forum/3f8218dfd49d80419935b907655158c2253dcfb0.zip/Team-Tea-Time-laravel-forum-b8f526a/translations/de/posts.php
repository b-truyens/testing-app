<?php

return [

    'actions' => 'Beitrag Aktionen',
    'created' => 'Beitrag erstellt',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Beitrag gelöscht|Beiträge gelöscht',
    'edit' => 'Beitrag bearbeiten',
    'last' => 'Letzter Beitrag',
    'perma_deleted' => 'Beitrag dauerhaft gelöscht|Beiträge dauerhaft gelöscht',
    'post' => 'Beitrag|Beiträge',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Beitrag wiederhergestellt|Beiträge wiederhergestellt',
    'select_all' => 'Select all posts',
    'updated' => 'Beitrag aktualisiert|Beiträge aktualisiert',
    'view' => 'Beitrag ansehen',
    'your_post' => 'Dein Beitrag',

];
