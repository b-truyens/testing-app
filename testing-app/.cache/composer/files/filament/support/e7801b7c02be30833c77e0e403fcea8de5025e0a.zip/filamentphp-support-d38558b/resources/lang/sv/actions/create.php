<?php

return [

    'single' => [

        'label' => 'Ny :label',

        'modal' => [

            'heading' => 'Skapa :label',

            'actions' => [

                'create' => [
                    'label' => 'Skapa',
                ],

                'create_another' => [
                    'label' => 'Skapa & skapa en till',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Skapad',
        ],

    ],

];
