<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'ចូលមើលឯកសារ',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
