<div class="filament-navigation">
    <hr class="-mx-6 border-gray-300 dark:border-gray-600">
</div>
