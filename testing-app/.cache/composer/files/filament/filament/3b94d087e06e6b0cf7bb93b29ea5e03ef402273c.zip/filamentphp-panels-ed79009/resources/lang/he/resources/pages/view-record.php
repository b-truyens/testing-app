<?php

return [

    'title' => 'תצוגת :label',

    'breadcrumb' => 'הצגה',

    'form' => [

        'tab' => [
            'label' => 'הצגה',
        ],

    ],

];
