<?php

return [

    'field' => [
        'label' => 'جستجو در کل سایت',
        'placeholder' => 'جستجو',
    ],

    'no_results_message' => 'نتیجه‌ای برای جستجو شما یافت نشد.',

];
