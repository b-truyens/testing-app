<?php

return [

    'single' => [

        'label' => 'Erota',

        'modal' => [

            'heading' => 'Erota :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Erota',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Erotettu',
        ],

    ],

    'multiple' => [

        'label' => 'Erota valitut',

        'modal' => [

            'heading' => 'Erota valitut :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Erota valitut',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Erotettu',
        ],

    ],

];
