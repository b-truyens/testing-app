<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dokumentacja',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
