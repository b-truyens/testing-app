<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dokumentáció',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
