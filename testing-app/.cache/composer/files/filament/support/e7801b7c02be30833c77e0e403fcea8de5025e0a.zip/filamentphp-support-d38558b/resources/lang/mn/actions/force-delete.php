<?php

return [

    'single' => [

        'label' => 'Устгах үйлдэл (force)',

        'modal' => [

            'heading' => 'Устгах :label',

            'actions' => [

                'delete' => [
                    'label' => 'Устгах',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Устгасан',
        ],

    ],

    'multiple' => [

        'label' => 'Сонгосон устгах',

        'modal' => [

            'heading' => 'Сонгосон устгах :label',

            'actions' => [

                'delete' => [
                    'label' => 'Устгах',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Устгасан',
        ],

    ],

];
