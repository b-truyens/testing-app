<?php

return [

    'title' => ':Label bekijken',

    'breadcrumb' => 'Bekijken',

    'form' => [

        'tab' => [
            'label' => 'Bekijken',
        ],

    ],

];
