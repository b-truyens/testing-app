<?php

return [

    'modal' => [

        'heading' => 'Aviseringar',

        'buttons' => [

            'clear' => [
                'label' => 'Rensa',
            ],

            'mark_all_as_read' => [
                'label' => 'Markera alla som lästa',
            ],

        ],

        'empty' => [
            'heading' => 'Inga aviseringar här',
            'description' => 'Kolla igen lite senare',
        ],

    ],

];
