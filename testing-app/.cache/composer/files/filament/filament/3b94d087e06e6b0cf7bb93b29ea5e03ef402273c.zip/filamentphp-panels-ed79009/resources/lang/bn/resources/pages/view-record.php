<?php

return [

    'title' => ':label দেখুন',

    'breadcrumb' => 'দেখুন',

    'form' => [

        'tab' => [
            'label' => 'দেখুন',
        ],

    ],

];
