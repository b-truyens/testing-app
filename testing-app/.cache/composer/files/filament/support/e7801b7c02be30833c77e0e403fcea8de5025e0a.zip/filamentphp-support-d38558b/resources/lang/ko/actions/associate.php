<?php

return [

    'single' => [

        'label' => '연결',

        'modal' => [

            'heading' => ':label 연결',

            'fields' => [

                'record_id' => [
                    'label' => '레코드',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => '연결',
                ],

                'associate_another' => [
                    'label' => '연결 및 계속하기',
                ],

            ],

        ],

        'messages' => [
            'associated' => '연결됨',
        ],

    ],

];
