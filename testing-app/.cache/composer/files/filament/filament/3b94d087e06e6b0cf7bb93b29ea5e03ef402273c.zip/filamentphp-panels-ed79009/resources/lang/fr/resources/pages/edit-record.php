<?php

return [

    'title' => 'Modifier :label',

    'breadcrumb' => 'Modifier',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Annuler',
            ],

            'save' => [
                'label' => 'Sauvegarder',
            ],

        ],

        'tab' => [
            'label' => 'Modifier',
        ],

    ],

    'messages' => [
        'saved' => 'Sauvegardé',
    ],

];
