<?php

namespace TeamTeaTime\Forum\Events\Types;

use Illuminate\Foundation\Events\Dispatchable;

class BaseEvent
{
    use Dispatchable;
}
