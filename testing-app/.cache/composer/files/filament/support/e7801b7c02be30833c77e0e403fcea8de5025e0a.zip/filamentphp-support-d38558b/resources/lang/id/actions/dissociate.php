<?php

return [

    'single' => [

        'label' => 'Pisahkan',

        'modal' => [

            'heading' => 'Pisahkan :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Pisahkan',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Data berhasil dipisahkan',
        ],

    ],

    'multiple' => [

        'label' => 'Pisahkan yang dipilih',

        'modal' => [

            'heading' => 'Pisahkan :label yang dipilih',

            'actions' => [

                'dissociate' => [
                    'label' => 'Pisahkan yang dipilih',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Data berhasil dipisahkan',
        ],

    ],

];
