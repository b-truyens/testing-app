<?php

return [

    'single' => [

        'label' => 'Tvångsradera',

        'modal' => [

            'heading' => 'Tvångsradera :label',

            'actions' => [

                'delete' => [
                    'label' => 'Radera',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Rad raderad',
        ],

    ],

    'multiple' => [

        'label' => 'Tvångsradera valda',

        'modal' => [

            'heading' => 'Tvångsradera valda :label',

            'actions' => [

                'delete' => [
                    'label' => 'Radera',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Rader raderade',
        ],

    ],

];
