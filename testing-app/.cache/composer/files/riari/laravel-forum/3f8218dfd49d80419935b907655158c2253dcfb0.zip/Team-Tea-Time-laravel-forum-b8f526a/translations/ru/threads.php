<?php

return [

    'actions' => 'Действия',
    'created' => 'Тема создана',
    'delete' => 'Удалить тему',
    'deleted' => 'Тема удалена|Темы удалены',
    'lock' => 'Закрыть',
    'locked' => 'Закрыто',
    'marked_read' => 'Все ветки были отмечены как прочитаные',
    'new_thread' => 'Новая ветка',
    'new_updated' => 'Новые и обновленные ветки',
    'newest' => 'Новейшая ветка',
    'none_found' => 'Нет веток',
    'perma_delete' => 'Permanently delete thread|Permanently delete threads',
    'perma_deleted' => 'Тема удалена навсегда|Темы удалены навсегда',
    'pin' => 'Закрепить',
    'pinned' => 'Закреплено',
    'post_the_first' => 'Напишите первым!',
    'restored' => 'Тема восстановлена|Темы восстановлены',
    'thread' => 'Тема|темы',
    'updated' => 'Тема обновлена|Темы обновлены',
    'unlock' => 'Открыть',
    'unpin' => 'открепить',
    'view' => 'Просмотреть ветку',

];
