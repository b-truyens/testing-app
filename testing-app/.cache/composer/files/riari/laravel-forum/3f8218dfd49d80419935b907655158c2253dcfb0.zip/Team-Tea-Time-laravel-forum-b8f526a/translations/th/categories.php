<?php

return [

    'access_controlled_by_private_ancestor' => 'The ancestor category :category is set as private and controls access to this category.',
    'actions' => 'จัดการหมวดหมู่',
    'category' => 'หมวดหมู่|หมวดหมู่',
    'confirm_nonempty_delete' => 'Yes, I want to permanently delete this category and everything inside it',
    'create' => 'เพิ่มหมวดหมู่',
    'created' => 'เพิ่มหมวดหมู่แล้ว',
    'deleted' => 'ลบหมวดหมู่แล้ว|ลบหมวดหมู่แล้ว',
    'disable_threads' => 'ปิดการเพิ่มหัวข้อใหม่',
    'enable_threads' => 'เปิดการเพิ่มหัวข้อใหม่',
    'make_private' => 'ตั้งค่าเป็นส่วนตัว',
    'make_public' => 'ตั้งค่าเป็นสาธารณะ',
    'mark_read' => 'ทำเครื่องหมายว่าอ่านแล้ว',
    'marked_read' => 'หัวข้อใน:categoryถูกบันทึกว่าอ่านแล้ว',
    'restored' => 'หมวดหมู่ถูกกู้คืนแล้ว|หมวดหมู่ถูกกู้คืนแล้ว',
    'subcategories' => 'หมวดหมู่ย่อย',
    'threads_disabled' => 'การเริ่มหัวข้อใหม่ถูกปิดการใช้งานในหมวดหมู่นี้',
    'updated' => 'อัพเดทหมวดหมู่แล้ว|อัพเดทหมวดหมู่แล้ว',

];
