<?php

return [

    'title' => 'Veure :label',

    'breadcrumb' => 'Veure',

    'form' => [

        'tab' => [
            'label' => 'Veure',
        ],

    ],

];
