<?php

return [

    'title' => 'Edytuj :label',

    'breadcrumb' => 'Edytuj',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Anuluj',
            ],

            'save' => [
                'label' => 'Zapisz',
            ],

        ],

        'tab' => [
            'label' => 'Edytuj',
        ],

    ],

    'messages' => [
        'saved' => 'Zapisano zmiany',
    ],

];
