<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'תיעוד',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
