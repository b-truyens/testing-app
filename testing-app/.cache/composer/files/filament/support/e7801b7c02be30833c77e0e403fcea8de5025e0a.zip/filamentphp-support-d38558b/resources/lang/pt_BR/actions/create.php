<?php

return [

    'single' => [

        'label' => 'Criar :label',

        'modal' => [

            'heading' => 'Criar :label',

            'actions' => [

                'create' => [
                    'label' => 'Criar',
                ],

                'create_another' => [
                    'label' => 'Salvar e criar novo',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Criado!',
        ],

    ],

];
