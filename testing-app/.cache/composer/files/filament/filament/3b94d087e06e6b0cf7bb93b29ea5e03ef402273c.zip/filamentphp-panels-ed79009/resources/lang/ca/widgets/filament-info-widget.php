<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Documentació',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
