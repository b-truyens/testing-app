<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => '도큐먼트',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
