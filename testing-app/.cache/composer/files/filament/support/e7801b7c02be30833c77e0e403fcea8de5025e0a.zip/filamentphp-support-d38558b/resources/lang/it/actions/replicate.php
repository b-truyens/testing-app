<?php

return [

    'single' => [

        'label' => 'Duplica',

        'messages' => [
            'replicated' => 'Duplicato',
        ],

    ],

];
