<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Փաստաթղթեր',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
