<?php

return [

    'single' => [

        'label' => 'إضافة',

        'modal' => [

            'heading' => 'إضافة :label',

            'actions' => [

                'create' => [
                    'label' => 'إضافة',
                ],

                'create_another' => [
                    'label' => 'إضافة وبدء إضافة المزيد',
                ],

            ],

        ],

        'messages' => [
            'created' => 'تمت الإضافة',
        ],

    ],

];
