<?php

return [

    'single' => [

        'label' => 'Nyahkait',

        'modal' => [

            'heading' => 'Nyahkait :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Nyahkait',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Ternyahkait',
        ],

    ],

    'multiple' => [

        'label' => 'Nyahkait pilihan',

        'modal' => [

            'heading' => 'Nyahkait pilihan :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Nyahkait',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Ternyahkait',
        ],

    ],

];
