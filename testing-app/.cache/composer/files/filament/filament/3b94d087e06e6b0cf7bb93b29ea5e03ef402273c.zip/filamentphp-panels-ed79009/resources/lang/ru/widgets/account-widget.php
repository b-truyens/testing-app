<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Выход',
        ],

    ],

    'welcome' => 'Добро пожаловать, :user',

];
