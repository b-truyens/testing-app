<?php

namespace Filament\Tables\Actions;

class RecordCheckboxPosition
{
    public const BeforeCells = 'before_cells';

    public const AfterCells = 'after_cells';
}
