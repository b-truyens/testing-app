<?php

return [

    'single' => [

        'label' => 'جیاکردنەوە',

        'modal' => [

            'heading' => 'جیاکردنەوەی :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'جیاکردنەوە',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'جیاکرایەوە',
        ],

    ],

    'multiple' => [

        'label' => 'جیاکراوە دیاری کرا',

        'modal' => [

            'heading' => 'دیاریکراوەکای :label جیابکەرەوە',

            'actions' => [

                'dissociate' => [
                    'label' => 'جیاکردنەوە',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'جیاکرایەوە',
        ],

    ],

];
