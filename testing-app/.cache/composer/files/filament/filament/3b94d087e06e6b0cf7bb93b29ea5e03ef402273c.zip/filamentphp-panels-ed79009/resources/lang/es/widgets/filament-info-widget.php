<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Documentación',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
