<?php

return [

    'single' => [

        'label' => 'Restaurar',

        'modal' => [

            'heading' => 'Restaurar :label',

            'actions' => [

                'restore' => [
                    'label' => 'Restaurar',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Restaurat',
        ],

    ],

    'multiple' => [

        'label' => 'Restaurar seleccionats',

        'modal' => [

            'heading' => 'Restaurar seleccionats :label',

            'actions' => [

                'restore' => [
                    'label' => 'Restaurar',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Restaurats',
        ],

    ],

];
