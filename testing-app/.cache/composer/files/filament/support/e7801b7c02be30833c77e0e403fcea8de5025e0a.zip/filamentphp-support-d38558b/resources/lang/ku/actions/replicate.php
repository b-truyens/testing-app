<?php

return [

    'single' => [

        'label' => 'لەبەر گرتنەوە',

        'modal' => [

            'heading' => 'لەبەر گرتنەوەی :label',

            'actions' => [

                'replicate' => [
                    'label' => 'لەبەر گرتنەوە',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'لەبەر گیرایەوە',
        ],

    ],

];
