<?php

return [

    'modal' => [

        'heading' => 'Bildirimler',

        'buttons' => [

            'clear' => [
                'label' => 'Temizle',
            ],

            'mark_all_as_read' => [
                'label' => 'Tümünü okundu işaretle',
            ],

        ],

        'empty' => [
            'heading' => 'Bildirim yok',
            'description' => 'Lütfen sonra kontrol ediniz',
        ],

    ],

];
