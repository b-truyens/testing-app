<?php

return [

    'single' => [

        'label' => 'Radera',

        'modal' => [

            'heading' => 'Radera :label',

            'actions' => [

                'delete' => [
                    'label' => 'Radera',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Raderad',
        ],

    ],

    'multiple' => [

        'label' => 'Radera valda',

        'modal' => [

            'heading' => 'Radera valda :label',

            'actions' => [

                'delete' => [
                    'label' => 'Radera',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Raderade',
        ],

    ],

];
