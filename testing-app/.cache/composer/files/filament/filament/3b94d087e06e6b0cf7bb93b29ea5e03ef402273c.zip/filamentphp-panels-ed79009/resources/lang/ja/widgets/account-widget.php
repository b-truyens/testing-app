<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'ログアウト',
        ],

    ],

    'welcome' => 'ようこそ, :user',

];
