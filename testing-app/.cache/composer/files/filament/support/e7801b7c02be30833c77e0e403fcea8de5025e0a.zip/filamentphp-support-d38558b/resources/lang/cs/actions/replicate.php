<?php

return [

    'single' => [

        'label' => 'Duplikovat',

        'modal' => [

            'heading' => 'Duplikovat :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplikovat',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Záznam duplikován',
        ],

    ],

];
