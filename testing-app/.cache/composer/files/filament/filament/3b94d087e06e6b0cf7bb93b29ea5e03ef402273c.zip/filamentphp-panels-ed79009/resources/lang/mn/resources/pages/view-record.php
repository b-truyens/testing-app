<?php

return [

    'title' => 'Харах :label',

    'breadcrumb' => 'Харах',

    'form' => [

        'tab' => [
            'label' => 'Харах',
        ],

    ],

];
