<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Documentação',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
