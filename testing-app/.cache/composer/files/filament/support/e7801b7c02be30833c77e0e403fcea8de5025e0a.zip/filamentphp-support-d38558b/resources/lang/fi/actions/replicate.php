<?php

return [

    'single' => [

        'label' => 'Monista',

        'modal' => [

            'heading' => 'Monista :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Monista',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Tietue monistettu',
        ],

    ],

];
