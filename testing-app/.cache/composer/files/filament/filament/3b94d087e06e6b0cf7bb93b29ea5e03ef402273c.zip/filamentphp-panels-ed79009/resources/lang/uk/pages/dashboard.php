<?php

return [

    'title' => 'Дешборд',

];
