<?php

return [

    'single' => [

        'label' => 'Smazat',

        'modal' => [

            'heading' => 'Smazat :label',

            'actions' => [

                'delete' => [
                    'label' => 'Smazat',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Smazáno',
        ],

    ],

    'multiple' => [

        'label' => 'Smazat vybrané',

        'modal' => [

            'heading' => 'Smazat vybrané :label',

            'actions' => [

                'delete' => [
                    'label' => 'Smazat vybrané',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Smazáno',
        ],

    ],

];
