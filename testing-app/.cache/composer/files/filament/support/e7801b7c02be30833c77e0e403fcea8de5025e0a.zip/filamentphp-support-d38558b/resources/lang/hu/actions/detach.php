<?php

return [

    'single' => [

        'label' => 'Leválasztás',

        'modal' => [

            'heading' => ':label leválasztása',

            'actions' => [

                'detach' => [
                    'label' => 'Leválasztás',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Leválasztva',
        ],

    ],

    'multiple' => [

        'label' => 'Kiválasztottak leválasztása',

        'modal' => [

            'heading' => 'Kiválasztott :label leválasztása',

            'actions' => [

                'detach' => [
                    'label' => 'Kiválasztottak leválasztása',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Leválasztva',
        ],

    ],

];
