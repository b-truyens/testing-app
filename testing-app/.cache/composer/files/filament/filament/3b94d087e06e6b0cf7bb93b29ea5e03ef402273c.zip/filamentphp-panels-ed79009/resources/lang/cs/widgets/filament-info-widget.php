<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dokumentace',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
