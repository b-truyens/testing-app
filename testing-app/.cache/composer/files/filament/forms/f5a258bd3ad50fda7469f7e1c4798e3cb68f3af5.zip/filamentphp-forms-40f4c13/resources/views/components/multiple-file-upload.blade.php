{{ $getChildComponentContainer() }}
