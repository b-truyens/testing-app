<?php

return [

    'single' => [

        'label' => 'Frigør',

        'modal' => [

            'heading' => 'Frigør :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Frigør',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Frigjort',
        ],

    ],

    'multiple' => [

        'label' => 'Frigør valgte',

        'modal' => [

            'heading' => 'Frigør valgte :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Frigør',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Frigjort',
        ],

    ],

];
