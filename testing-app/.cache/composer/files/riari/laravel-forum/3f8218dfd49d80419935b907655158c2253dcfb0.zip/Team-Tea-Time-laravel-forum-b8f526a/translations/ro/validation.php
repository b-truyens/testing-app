<?php

return [

    'category_threads_enabled' => 'Categoria trebuie să aibă fire activat.',
    'category_has_no_threads' => 'Categoria nu trebuie să conțină fire.',
    'category_is_empty' => 'Categoria trebuie să fie gol.',

];
