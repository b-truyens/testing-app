<?php

return [

    'title' => 'تعديل :label',

    'breadcrumb' => 'تعديل',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'إلغاء',
            ],

            'save' => [
                'label' => 'حفظ',
            ],

        ],

        'tab' => [
            'label' => 'تعديل',
        ],

    ],

    'messages' => [
        'saved' => 'تم الحفظ',
    ],

];
