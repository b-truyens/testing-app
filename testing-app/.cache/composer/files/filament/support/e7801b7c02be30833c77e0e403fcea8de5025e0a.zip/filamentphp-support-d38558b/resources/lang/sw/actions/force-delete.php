<?php

return [

    'single' => [

        'label' => 'Futa kwa lazima',

        'modal' => [

            'heading' => 'Futa kwa lazima :label',

            'actions' => [

                'delete' => [
                    'label' => 'Futa',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Imefutwa',
        ],

    ],

    'multiple' => [

        'label' => 'Futa kwa lazima chaguo',

        'modal' => [

            'heading' => 'Futa kwa lazima chaguo :label',

            'actions' => [

                'delete' => [
                    'label' => 'Futa',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Imefutwa',
        ],

    ],

];
