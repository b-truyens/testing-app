<?php

return [

    'buttons' => [

        'logout' => [
            'label' => '로그아웃',
        ],

    ],

    'welcome' => '어서오세요, :user',

];
