<?php

return [

    'single' => [

        'label' => 'Usuń',

        'modal' => [

            'heading' => 'Usuń :label',

            'actions' => [

                'delete' => [
                    'label' => 'Usuń',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Usunięto',
        ],

    ],

    'multiple' => [

        'label' => 'Usuń zaznaczone',

        'modal' => [

            'heading' => 'Usuń zaznaczone :label',

            'actions' => [

                'delete' => [
                    'label' => 'Usuń zaznaczone',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Usunięto',
        ],

    ],

];
