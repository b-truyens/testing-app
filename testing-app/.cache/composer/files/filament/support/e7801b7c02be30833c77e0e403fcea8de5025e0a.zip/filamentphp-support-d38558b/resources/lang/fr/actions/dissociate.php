<?php

return [

    'single' => [

        'label' => 'Dissocier',

        'modal' => [

            'heading' => 'Dissocier :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissocier',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Dissocié',
        ],

    ],

    'multiple' => [

        'label' => 'Dissocier sélection',

        'modal' => [

            'heading' => 'Dissocier la sélection :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissocier sélection',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Dissocié',
        ],

    ],

];
