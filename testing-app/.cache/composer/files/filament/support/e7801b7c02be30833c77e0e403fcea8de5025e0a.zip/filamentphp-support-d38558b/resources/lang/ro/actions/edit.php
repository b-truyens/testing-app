<?php

return [

    'single' => [

        'label' => 'Editare',

        'modal' => [

            'heading' => 'Editare :label',

            'actions' => [

                'save' => [
                    'label' => 'Salvare',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Salvat cu succes',
        ],

    ],

];
