<?php

return [

    'single' => [

        'label' => 'Adăugare :label',

        'modal' => [

            'heading' => 'Creare :label',

            'actions' => [

                'create' => [
                    'label' => 'Creare',
                ],

                'create_another' => [
                    'label' => 'Creați și creați altul',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Creat cu succes',
        ],

    ],

];
