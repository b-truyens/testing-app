<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Disconnetti',
        ],

    ],

    'welcome' => 'Benvenuto, :user',

];
