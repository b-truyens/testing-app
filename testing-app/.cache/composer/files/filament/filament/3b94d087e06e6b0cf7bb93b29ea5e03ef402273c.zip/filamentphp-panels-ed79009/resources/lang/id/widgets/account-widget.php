<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Keluar',
        ],

    ],

    'welcome' => 'Selamat Datang, :user',

];
