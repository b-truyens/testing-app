<?php

return [

    'single' => [

        'label' => 'Új :label',

        'modal' => [

            'heading' => 'Új :label',

            'actions' => [

                'create' => [
                    'label' => 'Hozzáadás',
                ],

                'create_another' => [
                    'label' => 'Hozzáadás és új hozzáadása',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Hozzáadva',
        ],

    ],

];
