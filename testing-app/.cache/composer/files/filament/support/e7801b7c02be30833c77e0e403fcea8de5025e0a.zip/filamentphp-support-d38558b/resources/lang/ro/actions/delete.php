<?php

return [

    'single' => [

        'label' => 'Ștergere',

        'modal' => [

            'heading' => 'Ștergere :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ștergere',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Șters cu succes',
        ],

    ],

    'multiple' => [

        'label' => 'Ștergeți înregistrările selectate',

        'modal' => [

            'heading' => 'Ștergeți :label selectate',

            'actions' => [

                'delete' => [
                    'label' => 'Ștergere',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Șters cu succes',
        ],

    ],

];
