<?php

return [

    'title' => 'Mostrar :label',

    'breadcrumb' => 'Mostrar',

];
