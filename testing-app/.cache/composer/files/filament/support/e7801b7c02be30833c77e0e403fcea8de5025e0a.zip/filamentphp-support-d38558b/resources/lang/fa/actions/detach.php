<?php

return [

    'single' => [

        'label' => 'جدا کردن',

        'modal' => [

            'heading' => 'جدا کردن :label',

            'actions' => [

                'detach' => [
                    'label' => 'جدا کردن',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'جدا شد',
        ],

    ],

    'multiple' => [

        'label' => 'جدا کردن انتخاب شده',

        'modal' => [

            'heading' => 'جدا کردن :label انتخاب شده',

            'actions' => [

                'detach' => [
                    'label' => 'جدا کردن انتخاب شده',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'جدا شد',
        ],

    ],

];
