<?php

return [

    'single' => [

        'label' => 'Editatu',

        'modal' => [

            'heading' => 'Editatu :label',

            'actions' => [

                'save' => [
                    'label' => 'Aldaketak gorde',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Gordeta',
        ],

    ],

];
