<?php

return [

    'single' => [

        'label' => 'Berreskuratu',

        'modal' => [

            'heading' => 'Berreskuratu :label',

            'actions' => [

                'restore' => [
                    'label' => 'Berreskuratu',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Erregistroa leheneratu da',
        ],

    ],

    'multiple' => [

        'label' => 'Hautatutakoak berreskuratu',

        'modal' => [

            'heading' => 'Berreskuratu :label hautatutakoak',

            'actions' => [

                'restore' => [
                    'label' => 'Berreskuratu',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Erregistroak leheneratu dira',
        ],

    ],

];
