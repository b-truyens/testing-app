<?php

return [

    'title' => 'Ubah :label',

    'breadcrumb' => 'Ubah',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Batal',
            ],

            'save' => [
                'label' => 'Simpan',
            ],

        ],

        'tab' => [
            'label' => 'Ubah',
        ],

    ],

    'messages' => [
        'saved' => 'Data berhasil disimpan',
    ],

];
