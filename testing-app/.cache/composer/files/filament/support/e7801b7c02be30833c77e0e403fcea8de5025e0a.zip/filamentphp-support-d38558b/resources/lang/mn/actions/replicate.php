<?php

return [

    'single' => [

        'label' => 'Олшруулах',

        'modal' => [

            'heading' => 'Олшруулах :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Олшруулах',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Олшруулав',
        ],

    ],

];
