<?php

return [

    'single' => [

        'label' => 'Banandu',

        'modal' => [

            'heading' => 'Banandu :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Banandu',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Bananduta',
        ],

    ],

    'multiple' => [

        'label' => 'Hautatutakoak banandu',

        'modal' => [

            'heading' => 'Banandu :label hautatutakoak',

            'actions' => [

                'dissociate' => [
                    'label' => 'Banandu',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Bananduta',
        ],

    ],

];
