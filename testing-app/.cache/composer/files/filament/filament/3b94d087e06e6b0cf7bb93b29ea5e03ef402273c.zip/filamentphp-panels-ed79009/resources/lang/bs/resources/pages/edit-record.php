<?php

return [

    'title' => 'Uredi :label',

    'breadcrumb' => 'Uredi',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Prekinit',
            ],

            'save' => [
                'label' => 'Saćuvaj',
            ],

        ],

        'tab' => [
            'label' => 'Uredi',
        ],

    ],

    'messages' => [
        'saved' => 'Sačuvano',
    ],

];
