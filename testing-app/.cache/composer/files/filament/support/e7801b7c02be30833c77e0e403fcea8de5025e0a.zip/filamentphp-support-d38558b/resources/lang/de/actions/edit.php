<?php

return [

    'single' => [

        'label' => 'Bearbeiten',

        'modal' => [

            'heading' => ':label bearbeiten',

            'actions' => [

                'save' => [
                    'label' => 'Speichern',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Gespeichert',
        ],

    ],

];
