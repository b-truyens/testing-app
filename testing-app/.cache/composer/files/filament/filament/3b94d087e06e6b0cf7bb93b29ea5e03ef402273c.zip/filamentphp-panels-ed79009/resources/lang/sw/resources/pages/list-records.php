<?php

return [

    'breadcrumb' => 'Listi',

];
