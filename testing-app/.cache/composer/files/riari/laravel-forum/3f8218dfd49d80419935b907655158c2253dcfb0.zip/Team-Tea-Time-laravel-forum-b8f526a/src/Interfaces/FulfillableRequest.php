<?php

namespace TeamTeaTime\Forum\Interfaces;

interface FulfillableRequest
{
    public function fulfill();
}
