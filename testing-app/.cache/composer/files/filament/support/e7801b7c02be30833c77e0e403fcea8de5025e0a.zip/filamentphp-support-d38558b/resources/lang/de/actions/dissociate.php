<?php

return [

    'single' => [

        'label' => 'Trennen',

        'modal' => [

            'heading' => ':label trennen',

            'actions' => [

                'dissociate' => [
                    'label' => 'Trennen',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Getrennt',
        ],

    ],

    'multiple' => [

        'label' => 'Ausgewählte trennen',

        'modal' => [

            'heading' => 'Ausgewählte :label trennen',

            'actions' => [

                'dissociate' => [
                    'label' => 'Ausgewählte trennen',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Getrennt',
        ],

    ],

];
