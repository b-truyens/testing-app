@php
    /** @deprecated */
@endphp
