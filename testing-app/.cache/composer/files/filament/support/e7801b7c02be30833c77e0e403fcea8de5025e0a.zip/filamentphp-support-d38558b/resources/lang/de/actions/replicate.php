<?php

return [

    'single' => [

        'label' => 'Duplizieren',

        'modal' => [

            'heading' => ':label duplizieren',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplizieren',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Eintrag dupliziert',
        ],

    ],

];
