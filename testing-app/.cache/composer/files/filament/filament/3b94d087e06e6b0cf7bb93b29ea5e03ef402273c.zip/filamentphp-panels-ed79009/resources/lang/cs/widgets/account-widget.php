<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Odhlásit se',
        ],

    ],

    'welcome' => 'Vítejte, :user',

];
