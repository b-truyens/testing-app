<?php

return [

    'single' => [

        'label' => 'حذف',

        'modal' => [

            'heading' => 'حذف :label',

            'actions' => [

                'delete' => [
                    'label' => 'حذف',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'حذف شد',
        ],

    ],

    'multiple' => [

        'label' => 'حذف انتخاب شده‌',

        'modal' => [

            'heading' => 'حذف :label انتخاب شده',

            'actions' => [

                'delete' => [
                    'label' => 'حذف انتخاب شده‌',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'حذف شد',
        ],

    ],

];
