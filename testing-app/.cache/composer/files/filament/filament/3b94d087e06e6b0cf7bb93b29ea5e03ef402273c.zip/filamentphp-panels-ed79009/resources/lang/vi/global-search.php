<?php

return [

    'field' => [
        'label' => 'Tìm kiếm toàn hệ thống',
        'placeholder' => 'Tìm kiếm',
    ],

    'no_results_message' => 'Không tìm thấy kết quả nào.',

];
