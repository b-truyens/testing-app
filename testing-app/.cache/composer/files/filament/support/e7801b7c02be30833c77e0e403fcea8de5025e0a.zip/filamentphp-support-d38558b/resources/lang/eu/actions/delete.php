<?php

return [

    'single' => [

        'label' => 'Ezabatu',

        'modal' => [

            'heading' => 'Ezabatu :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ezabatu',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Ezabatuta',
        ],

    ],

    'multiple' => [

        'label' => 'Hautatutakoak ezabatu',

        'modal' => [

            'heading' => 'Ezabatu hautatutako :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ezabatu',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Ezabatuak',
        ],

    ],

];
