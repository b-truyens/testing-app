<?php

return [

    'single' => [

        'label' => 'Rudisha',

        'modal' => [

            'heading' => 'Rudisha :label',

            'actions' => [

                'restore' => [
                    'label' => 'Rudisha',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Imerudishwa',
        ],

    ],

    'multiple' => [

        'label' => 'Rudisha chaguo',

        'modal' => [

            'heading' => 'Rudisha chaguo :label',

            'actions' => [

                'restore' => [
                    'label' => 'Rudisha',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Imerudishwa',
        ],

    ],

];
