<?php

return [

    'single' => [

        'label' => 'Ripristina',

        'modal' => [

            'heading' => 'Ripristina :label',

            'actions' => [

                'restore' => [
                    'label' => 'Ripristina',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Ripristinato',
        ],

    ],

    'multiple' => [

        'label' => 'Ripristina selezionati',

        'modal' => [

            'heading' => 'Ripristina selezionati :label',

            'actions' => [

                'restore' => [
                    'label' => 'Ripristina',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Ripristinati',
        ],

    ],

];
