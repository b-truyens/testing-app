<?php

return [

    'single' => [

        'label' => 'Erantzun',

        'modal' => [

            'heading' => 'Erantzun :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Erantzun',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Erantzunda',
        ],

    ],

];
