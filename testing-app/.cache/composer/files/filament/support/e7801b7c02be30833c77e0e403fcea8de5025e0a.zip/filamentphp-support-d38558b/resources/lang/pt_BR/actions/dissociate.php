<?php

return [

    'single' => [

        'label' => 'Dissociar',

        'modal' => [

            'heading' => 'Dissociar :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociar',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Dissociado',
        ],

    ],

    'multiple' => [

        'label' => 'Dissociar selecionado',

        'modal' => [

            'heading' => 'Dissociar selecionado :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociar',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Dissociado',
        ],

    ],

];
