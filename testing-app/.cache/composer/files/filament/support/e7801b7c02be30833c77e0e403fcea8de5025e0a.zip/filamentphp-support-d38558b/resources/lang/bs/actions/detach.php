<?php

return [

    'single' => [

        'label' => 'Odvojite',

        'modal' => [

            'heading' => 'Odvojite :label',

            'actions' => [

                'detach' => [
                    'label' => 'Odvojite',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Odvojeno',
        ],

    ],

    'multiple' => [

        'label' => 'Odvojite izabrani',

        'modal' => [

            'heading' => 'Odvojite izabrani :label',

            'actions' => [

                'detach' => [
                    'label' => 'Odvojite izabrani',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Odvojeno',
        ],

    ],

];
