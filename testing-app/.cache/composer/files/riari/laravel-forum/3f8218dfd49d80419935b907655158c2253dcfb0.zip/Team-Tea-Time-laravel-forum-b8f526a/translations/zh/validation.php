<?php

return [

    'category_threads_enabled' => '该分类必须启用贴子.',
    'category_has_no_threads' => '分类不得包含贴子.',
    'category_is_empty' => '分类必须为空.',

];
