<?php

return [

    'title' => 'Upravit :label',

    'breadcrumb' => 'Upravit',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Zrušit',
            ],

            'save' => [
                'label' => 'Uložit',
            ],

        ],

        'tab' => [
            'label' => 'Upravit',
        ],

    ],

    'messages' => [
        'saved' => 'Uloženo',
    ],

];
