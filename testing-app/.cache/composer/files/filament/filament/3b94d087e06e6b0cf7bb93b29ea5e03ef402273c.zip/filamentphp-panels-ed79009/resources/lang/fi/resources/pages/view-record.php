<?php

return [

    'title' => 'Näytä :label',

    'breadcrumb' => 'Näytä',

    'form' => [

        'tab' => [
            'label' => 'Näytä',
        ],

    ],

];
