<?php

return [

    'single' => [

        'label' => '복원',

        'modal' => [

            'heading' => '복원 :label',

            'actions' => [

                'restore' => [
                    'label' => '복원',
                ],

            ],

        ],

        'messages' => [
            'restored' => '복원됨',
        ],

    ],

    'multiple' => [

        'label' => '선택한 항목 복원',

        'modal' => [

            'heading' => ':label 선택한 항목 복원',

            'actions' => [

                'restore' => [
                    'label' => '복원',
                ],

            ],

        ],

        'messages' => [
            'restored' => '복원됨',
        ],

    ],

];
