<?php

return [

    'single' => [

        'label' => 'Piesaistīt',

        'modal' => [

            'heading' => 'Piesaistīt :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Ieraksts',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Piesaistīt',
                ],

                'attach_another' => [
                    'label' => 'Piesaistīt & piesaistīt citu',
                ],

            ],

        ],

        'messages' => [
            'attached' => 'Piesaistīts',
        ],

    ],

];
