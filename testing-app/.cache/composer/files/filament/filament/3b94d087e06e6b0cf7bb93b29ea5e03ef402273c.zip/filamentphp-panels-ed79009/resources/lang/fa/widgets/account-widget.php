<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'خروج',
        ],

    ],

    'welcome' => ':user خوش آمدید.',

];
