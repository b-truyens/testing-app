<?php

return [

    'single' => [

        'label' => '複製',

        'modal' => [

            'heading' => ':label複製',

            'actions' => [

                'replicate' => [
                    'label' => '複製',
                ],

            ],

        ],

        'messages' => [
            'replicated' => '複製しました',
        ],

    ],

];
