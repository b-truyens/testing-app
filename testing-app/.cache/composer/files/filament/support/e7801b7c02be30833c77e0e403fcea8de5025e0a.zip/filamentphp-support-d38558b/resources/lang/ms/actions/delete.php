<?php

return [

    'single' => [

        'label' => 'Padam',

        'modal' => [

            'heading' => 'Padam :label',

            'actions' => [

                'delete' => [
                    'label' => 'Padam',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Dipadamkan',
        ],

    ],

    'multiple' => [

        'label' => 'Padam pilihan',

        'modal' => [

            'heading' => 'Padam pilihan :label',

            'actions' => [

                'delete' => [
                    'label' => 'Padam pilihan',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Dipadamkan',
        ],

    ],

];
