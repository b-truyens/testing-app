<?php

return [

    'category_threads_enabled' => 'Die Erstellung neuer Themen muss in dieser Kategorie aktiviert sein.',
    'category_has_no_threads' => 'Die Kategorie darf keine Themen enthalten.',
    'category_is_empty' => 'Die Kategorie muss leer sein.',

];
