<?php

return [

    'title' => 'Peržiūrėti :label',

    'breadcrumb' => 'Peržiūrėti',

    'form' => [

        'tab' => [
            'label' => 'Peržiūrėti',
        ],

    ],

];
