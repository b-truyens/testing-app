<?php

return [

    'single' => [

        'label' => 'Ontkoppelen',

        'modal' => [

            'heading' => ':Label ontkoppelen',

            'actions' => [

                'dissociate' => [
                    'label' => 'Ontkoppelen',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Ontkoppeld',
        ],

    ],

    'multiple' => [

        'label' => 'Geselecteerde ontkoppelen',

        'modal' => [

            'heading' => 'Geselecteerde :label ontkoppelen',

            'actions' => [

                'dissociate' => [
                    'label' => 'Ontkoppelen',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Ontkoppeld',
        ],

    ],

];
