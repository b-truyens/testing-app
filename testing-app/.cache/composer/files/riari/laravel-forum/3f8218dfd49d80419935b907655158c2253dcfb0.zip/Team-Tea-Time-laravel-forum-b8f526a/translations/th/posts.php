<?php

return [

    'actions' => 'จัดการโพสต์',
    'created' => 'เพิ่มโพสต์แล้ว',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'โพสต์ถูกลบแล้ว|โพสต์ถูกลบแล้ว',
    'edit' => 'แก้ไขโพสต์',
    'last' => 'แก้ไขโพสต์ล่าสุด',
    'perma_deleted' => 'ลบโพสต์ถาวร|ลบโพสต์ถาวร',
    'post' => 'โพสต์|โพสต์',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'กู้คืนโพสต์|กู้คืนโพสต์',
    'select_all' => 'Select all posts',
    'updated' => 'โพสต์ถูกแก้ไขแล้ว|โพสต์ถูกแก้ไขแล้ว',
    'view' => 'ดูโพสต์',
    'your_post' => 'โพสต์ของคุณ',

];
