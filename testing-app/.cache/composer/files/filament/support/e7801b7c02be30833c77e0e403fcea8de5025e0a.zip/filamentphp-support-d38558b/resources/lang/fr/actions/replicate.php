<?php

return [

    'single' => [

        'label' => 'Dupliquer',

        'modal' => [

            'heading' => 'Dupliquer :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Dupliquer',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Enregistrement dupliqué',
        ],

    ],

];
