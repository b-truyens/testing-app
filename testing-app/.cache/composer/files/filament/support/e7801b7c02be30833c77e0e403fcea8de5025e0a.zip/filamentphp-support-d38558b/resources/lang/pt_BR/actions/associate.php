<?php

return [

    'single' => [

        'label' => 'Associar',

        'modal' => [

            'heading' => 'Associar :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Registro',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Associar',
                ],

                'associate_another' => [
                    'label' => 'Associar e Associar outro',
                ],

            ],

        ],

        'messages' => [
            'associated' => 'Associado',
        ],

    ],

];
