<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Log ud',
        ],

    ],

    'welcome' => 'Velkommen, :user',

];
