<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'साइन आउट',
        ],

    ],

    'welcome' => 'स्वागत, :user',

];
