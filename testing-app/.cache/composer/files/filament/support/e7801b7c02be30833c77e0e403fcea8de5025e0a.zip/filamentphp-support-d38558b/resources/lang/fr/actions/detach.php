<?php

return [

    'single' => [

        'label' => 'Détacher',

        'modal' => [

            'heading' => 'Détacher :label',

            'actions' => [

                'detach' => [
                    'label' => 'Détacher',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Détaché(e)',
        ],

    ],

    'multiple' => [

        'label' => 'Détacher la sélection',

        'modal' => [

            'heading' => 'Détacher la sélection de :label',

            'actions' => [

                'detach' => [
                    'label' => 'Détacher la sélection',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Détaché(e)s',
        ],

    ],

];
