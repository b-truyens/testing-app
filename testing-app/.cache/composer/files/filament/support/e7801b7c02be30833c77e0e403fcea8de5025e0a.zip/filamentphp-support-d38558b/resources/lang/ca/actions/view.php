<?php

return [

    'single' => [

        'label' => 'Veure',

        'modal' => [

            'heading' => 'Veure :label',

            'actions' => [

                'close' => [
                    'label' => 'Tancar',
                ],

            ],

        ],

    ],

];
