<?php

return [

    'single' => [

        'label' => 'Disociar',

        'modal' => [

            'heading' => 'Disociar :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Disociar',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Disociado',
        ],

    ],

    'multiple' => [

        'label' => 'Disociar seleccionados',

        'modal' => [

            'heading' => 'Disociar :label seleccionados',

            'actions' => [

                'dissociate' => [
                    'label' => 'Disociar',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Disociados',
        ],

    ],

];
