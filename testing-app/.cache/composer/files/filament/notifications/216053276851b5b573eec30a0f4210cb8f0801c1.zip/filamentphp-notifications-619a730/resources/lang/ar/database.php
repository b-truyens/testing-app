<?php

return [

    'modal' => [

        'heading' => 'التنبيهات',

        'buttons' => [

            'clear' => [
                'label' => 'مسح',
            ],

            'mark_all_as_read' => [
                'label' => 'تحديد الكل كمقروء',
            ],

        ],

        'empty' => [
            'heading' => 'لا توجد تنبيهات',
            'description' => 'يرجي التحقق مرة أخري لاحقا',
        ],

    ],

];
