<?php

return [

    'title' => ':label megtekintése',

    'breadcrumb' => 'Megtekintés',

    'form' => [

        'tab' => [
            'label' => 'Megtekintés',
        ],

    ],

];
