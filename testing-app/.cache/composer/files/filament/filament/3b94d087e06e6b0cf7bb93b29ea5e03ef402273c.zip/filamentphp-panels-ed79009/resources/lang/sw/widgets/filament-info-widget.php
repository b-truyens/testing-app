<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Nyaraka',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
