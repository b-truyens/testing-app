<?php

return [

    'title' => 'Muokkaa :label',

    'breadcrumb' => 'Muokkaa',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Peruuta',
            ],

            'save' => [
                'label' => 'Tallenna',
            ],

        ],

        'tab' => [
            'label' => 'Muokkaa',
        ],

    ],

    'messages' => [
        'saved' => 'Tallennettu',
    ],

];
