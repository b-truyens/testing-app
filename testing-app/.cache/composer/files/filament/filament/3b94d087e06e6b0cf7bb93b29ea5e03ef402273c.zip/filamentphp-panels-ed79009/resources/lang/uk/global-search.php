<?php

return [

    'field' => [
        'label' => 'Глобальний пошук',
        'placeholder' => 'Пошук',
    ],

    'no_results_message' => 'Не знайдено жодних результатів пошуку.',

];
