<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Οδηγός',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
