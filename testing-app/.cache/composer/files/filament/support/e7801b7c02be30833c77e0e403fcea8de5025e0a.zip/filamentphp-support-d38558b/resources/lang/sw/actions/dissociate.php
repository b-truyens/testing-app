<?php

return [

    'single' => [

        'label' => 'Tenganisha',

        'modal' => [

            'heading' => 'Tenganisha :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Tenganisha',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Imetenganishwa',
        ],

    ],

    'multiple' => [

        'label' => 'Tenganisha chaguo',

        'modal' => [

            'heading' => 'Tenganisha chaguo :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Tenganisha',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Imetenganishwa',
        ],

    ],

];
