<?php

return [

    'title' => 'Editar :label',

    'breadcrumb' => 'Editar',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Cancelar',
            ],

            'save' => [
                'label' => 'Salvar',
            ],

        ],

        'tab' => [
            'label' => 'Editar',
        ],

    ],

    'messages' => [
        'saved' => 'Salvo!',
    ],

];
