<?php

return [

    'single' => [

        'label' => 'Modifica',

        'modal' => [

            'heading' => 'Modifica :label',

            'actions' => [

                'save' => [
                    'label' => 'Salva',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Salvato',
        ],

    ],

];
