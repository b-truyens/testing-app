<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Iziet',
        ],

    ],

    'welcome' => 'Laipni lūdzam, :user',

];
