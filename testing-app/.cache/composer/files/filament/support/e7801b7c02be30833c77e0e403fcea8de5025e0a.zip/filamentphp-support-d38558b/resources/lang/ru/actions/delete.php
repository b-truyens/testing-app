<?php

return [

    'single' => [

        'label' => 'Удалить',

        'modal' => [

            'heading' => 'Удалить :label',

            'actions' => [

                'delete' => [
                    'label' => 'Удалить',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Удалено',
        ],

    ],

    'multiple' => [

        'label' => 'Удалить отмеченное',

        'modal' => [

            'heading' => 'Удалить отмеченное :label',

            'actions' => [

                'delete' => [
                    'label' => 'Удалить отмеченное',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Удалено',
        ],

    ],

];
