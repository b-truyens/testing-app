<?php

return [

    'title' => 'Angalia :label',

    'breadcrumb' => 'Angalia',

    'form' => [

        'tab' => [
            'label' => 'Angalia',
        ],

    ],

];
