<?php

return [

    'single' => [

        'label' => 'Atsieti',

        'modal' => [

            'heading' => 'Atsieti :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Atsieti',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Atsieta',
        ],

    ],

    'multiple' => [

        'label' => 'Atsieti pažymėtą',

        'modal' => [

            'heading' => 'Atsieti pažymėtą :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Atsieti',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Atsieta',
        ],

    ],

];
