<?php

return [

    'single' => [

        'label' => 'Editar',

        'modal' => [

            'heading' => 'Editar :label',

            'actions' => [

                'save' => [
                    'label' => 'Salvar',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Salvo!',
        ],

    ],

];
