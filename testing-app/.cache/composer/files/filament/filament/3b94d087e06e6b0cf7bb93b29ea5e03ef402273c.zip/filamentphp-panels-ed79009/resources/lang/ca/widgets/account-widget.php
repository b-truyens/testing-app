<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Sortir',
        ],

    ],

    'welcome' => 'Benvinguda/ut, :user',

];
