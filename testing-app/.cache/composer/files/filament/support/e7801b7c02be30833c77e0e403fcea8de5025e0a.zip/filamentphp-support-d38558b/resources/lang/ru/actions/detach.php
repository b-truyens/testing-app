<?php

return [

    'single' => [

        'label' => 'Открепить',

        'modal' => [

            'heading' => 'Открепить :label',

            'actions' => [

                'detach' => [
                    'label' => 'Открепить',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Откреплено',
        ],

    ],

    'multiple' => [

        'label' => 'Открепить',

        'modal' => [

            'heading' => 'Открепить отмеченное :label',

            'actions' => [

                'detach' => [
                    'label' => 'Открепить отмеченное',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Откреплено',
        ],

    ],

];
