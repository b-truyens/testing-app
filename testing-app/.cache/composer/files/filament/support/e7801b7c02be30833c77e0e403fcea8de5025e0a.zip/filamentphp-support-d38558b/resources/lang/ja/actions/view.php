<?php

return [

    'single' => [

        'label' => '表示',

        'modal' => [

            'heading' => ':label詳細',

            'actions' => [

                'close' => [
                    'label' => '閉じる',
                ],

            ],

        ],

    ],

];
