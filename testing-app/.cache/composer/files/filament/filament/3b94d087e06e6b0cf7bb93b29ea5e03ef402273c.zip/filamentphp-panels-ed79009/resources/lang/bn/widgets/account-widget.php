<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'সাইন আউট',
        ],

    ],

    'welcome' => 'স্বাগতম, :user',

];
