<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Ohjeet',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
