<?php

namespace Akaunting\Money\Exceptions;

use UnexpectedValueException;

class UnexpectedAmountException extends UnexpectedValueException
{
    //
}
