<?php

return [

    'title' => 'Vizualizare :label',

    'breadcrumb' => 'Vizualizare',

    'form' => [

        'tab' => [
            'label' => 'Vizualizare',
        ],

    ],

];
