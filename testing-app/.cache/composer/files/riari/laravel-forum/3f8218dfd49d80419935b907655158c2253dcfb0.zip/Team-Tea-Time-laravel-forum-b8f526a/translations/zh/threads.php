<?php

return [

    'actions' => '贴子操作',
    'created' => '贴子已创建',
    'delete' => '删除此贴子',
    'deleted' => '贴子已删除|贴子已删除',
    'lock' => '锁定',
    'locked' => '已锁定',
    'marked_read' => '所有贴子都已标记为已读',
    'new_thread' => '发贴',
    'newest' => '最新贴子',
    'none_found' => '未发现贴子',
    'perma_delete' => '永久删除贴子|永久删除贴子',
    'perma_deleted' => '贴子被永久删除|贴子被永久删除',
    'pin' => '固定',
    'pinned' => '已固定',
    'post_the_first' => '发布第一个!',
    'recent' => '最新贴子',
    'restored' => '贴子已恢复|贴子已恢复',
    'select_all' => '选择所有贴子',
    'thread' => '贴子|贴子',
    'updated' => '贴子已更新|贴子已更新',
    'unlock' => '解锁',
    'unpin' => '解除固定',
    'unread_updated' => '未读&已更新贴子',
    'view' => '查看贴子',

];
