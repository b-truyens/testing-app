<?php

return [

    'title' => ':label संपादित करें',

    'breadcrumb' => 'संपादन',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'रद्द करें',
            ],

            'save' => [
                'label' => 'सेव',
            ],

        ],

    ],

    'messages' => [
        'saved' => 'सेव हो गया',
    ],

];
