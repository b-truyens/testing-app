<?php

return [

    'single' => [

        'label' => 'Desvincular',

        'modal' => [

            'heading' => 'Desvincular :label',

            'actions' => [

                'detach' => [
                    'label' => 'Desvincular',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Desvinculat',
        ],

    ],

    'multiple' => [

        'label' => 'Desvincular seleccionats',

        'modal' => [

            'heading' => 'Desvincular seleccionats :label',

            'actions' => [

                'detach' => [
                    'label' => 'Desvincular',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Desvinculats',
        ],

    ],

];
