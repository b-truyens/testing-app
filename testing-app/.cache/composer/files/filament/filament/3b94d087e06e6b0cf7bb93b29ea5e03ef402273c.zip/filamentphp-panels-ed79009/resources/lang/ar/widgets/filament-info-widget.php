<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'التوثيق',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
