<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Kirjaudu ulos',
        ],

    ],

    'welcome' => 'Tervetuloa, :user',

];
