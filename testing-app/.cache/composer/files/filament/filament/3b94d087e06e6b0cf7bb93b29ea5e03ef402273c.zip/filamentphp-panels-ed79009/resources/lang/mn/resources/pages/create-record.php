<?php

return [

    'title' => 'Шинэ :label',

    'breadcrumb' => 'Шинэ',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Цуцлах',
            ],

            'create' => [
                'label' => 'Шинэ',
            ],

            'create_another' => [
                'label' => 'Хадгалах & Шинээр үүсгэх',
            ],

        ],

    ],

    'messages' => [
        'created' => 'Шинээр үүссэн',
    ],

];
