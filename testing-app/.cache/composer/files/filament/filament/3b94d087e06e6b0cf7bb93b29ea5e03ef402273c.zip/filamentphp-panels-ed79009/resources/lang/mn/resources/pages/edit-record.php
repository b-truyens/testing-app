<?php

return [

    'title' => 'Засах :label',

    'breadcrumb' => 'Засах',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Цуцлах',
            ],

            'save' => [
                'label' => 'Хадгалах',
            ],

        ],

        'tab' => [
            'label' => 'Засах',
        ],

    ],

    'messages' => [
        'saved' => 'Засагдсан',
    ],

];
