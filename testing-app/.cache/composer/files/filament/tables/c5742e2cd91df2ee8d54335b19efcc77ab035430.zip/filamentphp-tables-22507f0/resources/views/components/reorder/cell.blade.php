<td
    {{ $attributes->class(['filament-tables-reorder-cell w-4 whitespace-nowrap px-4']) }}
>
    {{ $slot }}
</td>
