<?php

return [

    'category_threads_enabled' => 'La categoria deve avere discussioni abilitate.',
    'category_has_no_threads' => 'La categoria non deve contenere discussioni.',
    'category_is_empty' => 'La categoria deve essere vuota.',

];
