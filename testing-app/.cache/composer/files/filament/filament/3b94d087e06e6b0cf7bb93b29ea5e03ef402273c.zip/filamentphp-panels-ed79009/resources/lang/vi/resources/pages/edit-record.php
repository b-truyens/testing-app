<?php

return [

    'title' => 'Chỉnh sửa :label',

    'breadcrumb' => 'Chỉnh sửa',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Quay lại',
            ],

            'save' => [
                'label' => 'Lưu thay đổi',
            ],

        ],

        'tab' => [
            'label' => 'Chỉnh sửa',
        ],

    ],

    'messages' => [
        'saved' => 'Đã lưu',
    ],

];
