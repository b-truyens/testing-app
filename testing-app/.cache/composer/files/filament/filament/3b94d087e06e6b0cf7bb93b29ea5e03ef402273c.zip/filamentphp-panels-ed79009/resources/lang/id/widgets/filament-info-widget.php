<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dokumentasi',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
