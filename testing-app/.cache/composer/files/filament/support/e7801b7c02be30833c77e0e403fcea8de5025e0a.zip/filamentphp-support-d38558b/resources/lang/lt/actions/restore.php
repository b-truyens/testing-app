<?php

return [

    'single' => [

        'label' => 'Atkurti',

        'modal' => [

            'heading' => 'Atkurti :label',

            'actions' => [

                'restore' => [
                    'label' => 'Atkurti',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Atkurta',
        ],

    ],

    'multiple' => [

        'label' => 'Atkurti pasirinktus',

        'modal' => [

            'heading' => 'Atkurti pasirinktus :label',

            'actions' => [

                'restore' => [
                    'label' => 'Atkurti',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Atkurta',
        ],

    ],

];
