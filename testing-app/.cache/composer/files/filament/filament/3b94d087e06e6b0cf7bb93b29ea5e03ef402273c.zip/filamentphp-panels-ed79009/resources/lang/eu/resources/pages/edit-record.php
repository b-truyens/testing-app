<?php

return [

    'title' => 'Editatu :label',

    'breadcrumb' => 'Editatu',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Ezeztatu',
            ],

            'save' => [
                'label' => 'Aldaketak gorde',
            ],

        ],

        'tab' => [
            'label' => 'Editatu',
        ],

    ],

    'messages' => [
        'saved' => 'Gordeta',
    ],

];
