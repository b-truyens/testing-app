<?php

return [

    'single' => [

        'label' => 'Edytuj',

        'modal' => [

            'heading' => 'Edytuj :label',

            'actions' => [

                'save' => [
                    'label' => 'Zapisz',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Zmiany zapisane',
        ],

    ],

];
