<?php

return [

    'trigger' => [
        'label' => 'Acties',
    ],

];
