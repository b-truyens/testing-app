<?php

return [

    'single' => [

        'label' => 'حذف نهائي',

        'modal' => [

            'heading' => 'حذف نهائي لـ :label',

            'actions' => [

                'delete' => [
                    'label' => 'حذف',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'تم حذف السجل',
        ],

    ],

    'multiple' => [

        'label' => 'حذف المحدد نهائيا',

        'modal' => [

            'heading' => 'حذف نهائي لـ :label',

            'actions' => [

                'delete' => [
                    'label' => 'حذف',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'تم حذف السجلات',
        ],

    ],

];
