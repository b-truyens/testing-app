<?php

namespace Laravel\Jetstream\Contracts;

/**
 * @method void remove(\Illuminate\Foundation\Auth\User $user, \Illuminate\Database\Eloquent\Model $team, \Illuminate\Foundation\Auth\User $teamMember)
 */
interface RemovesTeamMembers
{
    //
}
