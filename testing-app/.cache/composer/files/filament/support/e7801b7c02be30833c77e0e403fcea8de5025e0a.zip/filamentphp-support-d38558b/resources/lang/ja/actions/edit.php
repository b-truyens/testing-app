<?php

return [

    'single' => [

        'label' => '編集',

        'modal' => [

            'heading' => ':label編集',

            'actions' => [

                'save' => [
                    'label' => '保存',
                ],

            ],

        ],

        'messages' => [
            'saved' => '保存しました',
        ],

    ],

];
