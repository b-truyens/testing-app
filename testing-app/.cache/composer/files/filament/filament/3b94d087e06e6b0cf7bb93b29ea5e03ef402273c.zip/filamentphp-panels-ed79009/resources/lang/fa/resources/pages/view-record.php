<?php

return [

    'title' => 'مشاهده :label',

    'breadcrumb' => 'مشاهده',

    'form' => [

        'tab' => [
            'label' => 'مشاهده',
        ],

    ],

];
