<?php

return [

    'single' => [

        'label' => 'Nou :label',

        'modal' => [

            'heading' => 'Creat :label',

            'actions' => [

                'create' => [
                    'label' => 'Creat',
                ],

                'create_another' => [
                    'label' => 'Creat & crear un altre',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Creat',
        ],

    ],

];
