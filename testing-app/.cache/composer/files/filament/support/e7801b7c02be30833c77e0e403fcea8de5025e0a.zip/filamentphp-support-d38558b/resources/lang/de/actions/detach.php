<?php

return [

    'single' => [

        'label' => 'Trennen',

        'modal' => [

            'heading' => ':label trennen',

            'actions' => [

                'detach' => [
                    'label' => 'Trennen',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Getrennt',
        ],

    ],

    'multiple' => [

        'label' => 'Ausgewählte trennen',

        'modal' => [

            'heading' => 'Ausgewählte :label trennen',

            'actions' => [

                'detach' => [
                    'label' => 'Ausgewählte trennen',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Getrennt',
        ],

    ],

];
