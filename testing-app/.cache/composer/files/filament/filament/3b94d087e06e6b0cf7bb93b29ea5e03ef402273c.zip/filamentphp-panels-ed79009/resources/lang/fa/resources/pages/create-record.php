<?php

return [

    'title' => 'ساختن :label',

    'breadcrumb' => 'ساختن',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'لغو',
            ],

            'create' => [
                'label' => 'ساختن',
            ],

            'create_another' => [
                'label' => 'ساختن و ساختن یکی دیگر',
            ],

        ],

    ],

    'messages' => [
        'created' => 'ساخته شد',
    ],

];
