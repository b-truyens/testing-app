<?php

return [

    'single' => [

        'label' => 'Redaguoti',

        'modal' => [

            'heading' => 'Redaguoti :label',

            'actions' => [

                'save' => [
                    'label' => 'Išsaugoti pakeitimus',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Išsaugota',
        ],

    ],

];
