<?php

return [

    'direction' => 'ទិសដៅពីឆ្វេងទៅស្ដាំ',

    'buttons' => [
        'logout' => [
            'label' => 'ចាកចេញពីកម្មវិធីប្រព័ន្ធ',
        ],

        'user_menu' => [
            'label' => 'ម៉ឺនុយអ្នកប្រើ',
        ],
    ],

];
