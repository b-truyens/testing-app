<?php

return [

    'title' => 'Хянах самбар',

];
