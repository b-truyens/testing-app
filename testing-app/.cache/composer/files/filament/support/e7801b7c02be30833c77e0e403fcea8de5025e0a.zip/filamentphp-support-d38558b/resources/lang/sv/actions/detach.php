<?php

return [

    'single' => [

        'label' => 'Koppla loss',

        'modal' => [

            'heading' => 'Koppla loss :label',

            'actions' => [

                'detach' => [
                    'label' => 'Koppla loss',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Koppling släppt',
        ],

    ],

    'multiple' => [

        'label' => 'Koppla loss valda',

        'modal' => [

            'heading' => 'Koppla loss valda :label',

            'actions' => [

                'detach' => [
                    'label' => 'Koppla loss valda',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Koppling släppt',
        ],

    ],

];
