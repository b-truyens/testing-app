<?php

return [

    'single' => [

        'label' => 'Replicēt',

        'modal' => [

            'heading' => 'Replicēt :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Replicēt',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Replicēts',
        ],

    ],

];
