<?php

return [

    'modal' => [

        'heading' => 'Notificações',

        'buttons' => [

            'clear' => [
                'label' => 'Limpar',
            ],

            'mark_all_as_read' => [
                'label' => 'Marcar tudo como lido',
            ],

        ],

        'empty' => [
            'heading' => 'Sem notificações aqui',
            'description' => 'Por favor, verifique mais tarde',
        ],

    ],

];
