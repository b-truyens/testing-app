<p {{ $attributes->class(['filament-tables-header-description']) }}>
    {{ $slot }}
</p>
