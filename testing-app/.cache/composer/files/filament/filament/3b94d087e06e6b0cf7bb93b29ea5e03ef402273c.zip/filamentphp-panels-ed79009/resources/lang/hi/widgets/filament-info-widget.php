<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'प्रलेखन',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
