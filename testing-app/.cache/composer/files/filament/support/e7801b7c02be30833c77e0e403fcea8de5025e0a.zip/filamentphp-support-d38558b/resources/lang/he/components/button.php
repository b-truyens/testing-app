<?php

return [

    'messages' => [
        'uploading_file' => 'מעלה קבצים...',
    ],

];
