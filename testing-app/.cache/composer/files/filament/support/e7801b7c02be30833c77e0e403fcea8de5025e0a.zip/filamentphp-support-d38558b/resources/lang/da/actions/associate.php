<?php

return [

    'single' => [

        'label' => 'Tilknyt',

        'modal' => [

            'heading' => 'Tilknyt :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Post',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Tilknyt',
                ],

                'associate_another' => [
                    'label' => 'Tilknyt og tilknyt en mere',
                ],

            ],

        ],

        'messages' => [
            'associated' => 'Tilknyttet',
        ],

    ],

];
