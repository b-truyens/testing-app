<?php

return [

    'title' => ':Label bewerken',

    'breadcrumb' => 'Bewerken',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Annuleren',
            ],

            'save' => [
                'label' => 'Wijzigingen opslaan',
            ],

        ],

        'tab' => [
            'label' => 'Bewerken',
        ],

    ],

    'messages' => [
        'saved' => 'Opgeslagen',
    ],

];
