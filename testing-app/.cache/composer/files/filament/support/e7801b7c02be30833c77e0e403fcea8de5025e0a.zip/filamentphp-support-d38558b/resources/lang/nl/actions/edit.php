<?php

return [

    'single' => [

        'label' => 'Bewerken',

        'modal' => [

            'heading' => ':Label bewerken',

            'actions' => [

                'save' => [
                    'label' => 'Wijzigingen opslaan',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Opgeslagen',
        ],

    ],

];
