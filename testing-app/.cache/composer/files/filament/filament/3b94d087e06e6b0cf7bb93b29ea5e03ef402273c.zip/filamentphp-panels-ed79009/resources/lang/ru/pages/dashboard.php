<?php

return [

    'title' => 'Дашборд',

];
