<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Sign out',
        ],

    ],

    'welcome' => 'Welcome, :user',

];
