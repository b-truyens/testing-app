<?php

return [

    'single' => [

        'label' => 'Салгах',

        'modal' => [

            'heading' => 'Салгах :label',

            'actions' => [

                'detach' => [
                    'label' => 'Салгах',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Салгасан',
        ],

    ],

    'multiple' => [

        'label' => 'Сонгосонг салгах',

        'modal' => [

            'heading' => 'Салгах :label',

            'actions' => [

                'detach' => [
                    'label' => 'Салгах',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Салгасан',
        ],

    ],

];
