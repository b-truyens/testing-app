<?php

return [

    'title' => ':label সম্পাদন',

    'breadcrumb' => 'সম্পাদন করুন',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'বাতিল',
            ],

            'save' => [
                'label' => 'সম্পাদন করুন',
            ],

        ],

        'tab' => [
            'label' => 'সম্পাদন',
        ],

    ],

    'messages' => [
        'saved' => 'সম্পাদন করা হয়েছে',
    ],

];
