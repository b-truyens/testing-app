<?php

namespace Leandrocfe\FilamentApexCharts;

class FilamentApexCharts
{
}
