<?php

return [

    'title' => '创建 :label',

    'breadcrumb' => '创建',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => '取消',
            ],

            'create' => [
                'label' => '保存',
            ],

            'create_another' => [
                'label' => '保存并创建另一个',
            ],

        ],

    ],

    'messages' => [
        'created' => '已创建',
    ],

];
