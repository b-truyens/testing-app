<?php

return [

    'title' => 'عرض :label',

    'breadcrumb' => 'عرض',

    'form' => [

        'tab' => [
            'label' => 'عرض',
        ],

    ],

];
