<?php

return [

    'title' => 'Sortu :label',

    'breadcrumb' => 'Sortu',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Ezeztatu',
            ],

            'create' => [
                'label' => 'Sortu',
            ],

            'create_another' => [
                'label' => 'Sortu eta berri bat sortu',
            ],

        ],

    ],

    'messages' => [
        'created' => 'Sortuta',
    ],

];
