<?php

return [

    'single' => [

        'label' => 'Шинэ :label',

        'modal' => [

            'heading' => 'Шинэ :label',

            'actions' => [

                'create' => [
                    'label' => 'Шинэ',
                ],

                'create_another' => [
                    'label' => 'Хадгалаад & дахин шинийг үүсгэх',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Үүсэв',
        ],

    ],

];
