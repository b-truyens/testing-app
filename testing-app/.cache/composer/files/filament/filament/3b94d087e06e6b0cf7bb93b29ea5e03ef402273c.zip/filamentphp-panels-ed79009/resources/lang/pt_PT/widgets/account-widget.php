<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Terminar Sessão',
        ],

    ],

    'welcome' => 'Bem-vindo, :user',

];
