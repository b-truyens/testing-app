<?php

return [

    'single' => [

        'label' => 'لێکردنەوە',

        'modal' => [

            'heading' => 'لێکردنەوەی :label',

            'actions' => [

                'detach' => [
                    'label' => 'لێکردنەوە',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'لێکرایەوە',
        ],

    ],

    'multiple' => [

        'label' => 'دیاریکراوەکان لێبکەرەوە',

        'modal' => [

            'heading' => 'دیاریکراوی :label لێبکەرەوە',

            'actions' => [

                'detach' => [
                    'label' => 'دیاریکراوەکان لێبکەرەوە',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'لێکرایەوە',
        ],

    ],

];
