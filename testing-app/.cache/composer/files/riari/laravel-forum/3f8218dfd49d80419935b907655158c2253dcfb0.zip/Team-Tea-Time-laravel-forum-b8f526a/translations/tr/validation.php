<?php

return [

    'category_threads_enabled' => 'Kategori etkin Konuları olması gerekir.',
    'category_has_no_threads' => 'Kategori konuları içermemelidir.',
    'category_is_empty' => 'Kategori boş olmalıdır.',

];
