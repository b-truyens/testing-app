<?php

return [

    'single' => [

        'label' => 'Rediger',

        'modal' => [

            'heading' => 'Rediger :label',

            'actions' => [

                'save' => [
                    'label' => 'Gem ændringer',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Gemt',
        ],

    ],

];
