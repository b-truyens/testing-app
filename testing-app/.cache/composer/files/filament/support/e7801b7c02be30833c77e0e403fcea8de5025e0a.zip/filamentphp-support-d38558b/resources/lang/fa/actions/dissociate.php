<?php

return [

    'single' => [

        'label' => 'جداکردن',

        'modal' => [

            'heading' => 'جداکردن :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'جداکردن',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'جداکردن',
        ],

    ],

    'multiple' => [

        'label' => 'جداکردن انتخاب شده',

        'modal' => [

            'heading' => 'جداکردن :label انتخاب شده',

            'actions' => [

                'dissociate' => [
                    'label' => 'جداکردن انتخاب شده',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'جدا شد',
        ],

    ],

];
