<?php

return [

    'single' => [

        'label' => 'Копировать',

        'modal' => [

            'heading' => 'Копировать :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Копировать',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Запись скопирована',
        ],

    ],

];
