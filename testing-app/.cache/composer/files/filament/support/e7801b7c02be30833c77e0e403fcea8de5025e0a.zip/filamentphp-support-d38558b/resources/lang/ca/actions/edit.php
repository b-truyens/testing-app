<?php

return [

    'single' => [

        'label' => 'Modificar',

        'modal' => [

            'heading' => 'Modificar :label',

            'actions' => [

                'save' => [
                    'label' => 'Guardar canvis',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Guardat',
        ],

    ],

];
