<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'התנתק',
        ],

    ],

    'welcome' => 'ברוך הבא :user',

];
