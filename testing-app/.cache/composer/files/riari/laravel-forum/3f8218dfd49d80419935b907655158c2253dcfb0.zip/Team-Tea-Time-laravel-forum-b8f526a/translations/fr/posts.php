<?php

return [

    'actions' => 'Actions sur les messages',
    'created' => 'Message créé',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Message supprimé|Messages supprimés',
    'edit' => 'Modifier un message',
    'last' => 'Dernière message',
    'perma_deleted' => 'Message définitivement supprimé|Messages définitivement supprimés',
    'post' => 'Message|Messages',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Message restauré|Messages restaurés',
    'select_all' => 'Select all posts',
    'updated' => 'Message mis à jour|Messages mis à jour',
    'view' => 'Voir le message',
    'your_post' => 'Votre message',

];
