<?php

return [

    'category_threads_enabled' => 'U kategoriji moraju biti omogućene teme.',
    'category_has_no_threads' => 'Kategorija ne sme da ima teme.',
    'category_is_empty' => 'Kategorija mora biti prazna.',

];
