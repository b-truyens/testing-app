<x-forms::actions.action
    :action="$action"
    :label="$getLabel()"
    component="forms::icon-button"
    class="filament-forms-icon-button-action -my-2"
/>
