<?php

return [

    'single' => [

        'label' => 'لکاندن',

        'modal' => [

            'heading' => ':label بیلکێنە',

            'fields' => [

                'record_id' => [
                    'label' => 'تۆمار',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'بیلکێنە',
                ],

                'attach_another' => [
                    'label' => 'لکاندن و دانەیەکی تر',
                ],

            ],

        ],

        'messages' => [
            'attached' => 'لکێنرا',
        ],

    ],

];
