<?php

return [

    'single' => [

        'label' => 'Piespiedu dzēst',

        'modal' => [

            'heading' => 'Piespiedu dzēst :label',

            'actions' => [

                'delete' => [
                    'label' => 'Dzēst',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Dzēsts',
        ],

    ],

    'multiple' => [

        'label' => 'Piespiedu dzēst atzīmētos',

        'modal' => [

            'heading' => 'Piespiedu dzēst atzīmēto :label',

            'actions' => [

                'delete' => [
                    'label' => 'Dzēst',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Dzēsti',
        ],

    ],

];
