<?php

return [

    'single' => [

        'label' => 'Associat',

        'modal' => [

            'heading' => 'Associar :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Registre',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Associar',
                ],

                'associate_another' => [
                    'label' => 'Associar & associar un altre',
                ],

            ],

        ],

        'messages' => [
            'associated' => 'Associat',
        ],

    ],

];
