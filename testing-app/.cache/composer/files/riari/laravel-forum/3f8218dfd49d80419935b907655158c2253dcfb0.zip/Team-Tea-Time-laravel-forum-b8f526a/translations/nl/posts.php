<?php

return [

    'actions' => 'Reactie acties',
    'created' => 'Reactie aangemaakt',
    'delete' => 'Verwijder reactie|Verwijder reacties',
    'deleted' => 'Reactie verwijderd|Reacties verwijderd',
    'edit' => 'Wijzig reactie',
    'last' => 'Laatste reactie',
    'perma_deleted' => 'Reactie permanent verwijderd|Reacties permanent verwijderd',
    'post' => 'Reactie|Reacties',
    'restore' => 'Reactie herstellen|Reacties herstellen',
    'restored' => 'Reactie hersteld|Reacties hersteld',
    'select_all' => 'Selecteer alle reacties',
    'updated' => 'Reactie bijgewerkt|Reacties bijgewerkt',
    'view' => 'Bekijk reactie',
    'your_post' => 'Jouw reactie',

];
