<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Atsijungti',
        ],

    ],

    'welcome' => 'Sveiki atvykę, :user',

];
