<?php

return [

    'category_threads_enabled' => 'A categoria deve ter tópicos ativado.',
    'category_has_no_threads' => 'A categoria não deve conter tópicos.',
    'category_is_empty' => 'A categoria deve estar vazia.',

];
