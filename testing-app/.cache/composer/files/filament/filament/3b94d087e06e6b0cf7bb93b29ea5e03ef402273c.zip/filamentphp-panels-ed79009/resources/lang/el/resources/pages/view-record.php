<?php

return [

    'title' => 'Προεπισκόπηση :label',

    'breadcrumb' => 'Προεπισκόπηση',

    'form' => [

        'tab' => [
            'label' => 'Προεπισκόπηση',
        ],

    ],

];
