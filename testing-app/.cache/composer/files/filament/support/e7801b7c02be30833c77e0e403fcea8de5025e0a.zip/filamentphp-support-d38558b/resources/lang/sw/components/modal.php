<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Funga',
        ],

    ],

];
