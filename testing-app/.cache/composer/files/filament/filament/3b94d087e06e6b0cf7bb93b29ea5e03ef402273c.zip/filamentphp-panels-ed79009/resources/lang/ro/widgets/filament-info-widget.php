<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Documentație',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
