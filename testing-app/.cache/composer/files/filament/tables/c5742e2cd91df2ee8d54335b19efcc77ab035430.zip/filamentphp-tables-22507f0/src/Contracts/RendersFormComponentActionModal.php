<?php

namespace Filament\Tables\Contracts;

interface RendersFormComponentActionModal
{
}
