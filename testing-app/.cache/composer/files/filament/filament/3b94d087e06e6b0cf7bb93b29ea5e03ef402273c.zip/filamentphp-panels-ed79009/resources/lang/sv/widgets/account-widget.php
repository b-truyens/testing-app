<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Logga ut',
        ],

    ],

    'welcome' => 'Välkommen, :user',

];
