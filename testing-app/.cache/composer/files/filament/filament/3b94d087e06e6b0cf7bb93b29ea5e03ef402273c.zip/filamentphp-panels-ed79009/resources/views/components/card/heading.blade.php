<h2
    {{ $attributes->class(['filament-card-heading text-xl font-semibold tracking-tight']) }}
>
    {{ $slot }}
</h2>
