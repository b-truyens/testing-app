<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Odjava',
        ],

    ],

    'welcome' => 'Zdravo, :user',

];
