<?php

return [

    'actions' => 'Ações da postagem',
    'created' => 'Postagem criada',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Postagem deletada|Postagens deletadas',
    'edit' => 'Editar postagem',
    'last' => 'Última postagem',
    'perma_deleted' => 'Postagem permanentemente deletada|Postagens permanentementes deletadas',
    'post' => 'Postagem|Postagens',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Postagem restaurada|Postagens restauradas',
    'select_all' => 'Select all posts',
    'updated' => 'Postagem atualizada|Postagens atualizadas',
    'view' => 'Ver postagem',
    'your_post' => 'Sua postagem',

];
