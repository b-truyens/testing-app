<?php

return [

    'actions' => 'Mesaj ayarları',
    'created' => 'Mesaj gönderildi',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Mesaj silindi|Mesajlar silindi',
    'edit' => 'Mesaj düzenle',
    'last' => 'Son mesaj',
    'perma_deleted' => 'Mesaj kalıcı silindi|Mesajlar kalıncı olarak silindi',
    'post' => 'Mesaj|Mesajlar',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Mesaj geri alındı|Mesajlar geri alındı',
    'select_all' => 'Select all posts',
    'updated' => 'Mesaj güncellendi|Mesajlar güncellendi',
    'view' => 'Mesajı görüntüle',
    'your_post' => 'Sizin mesajınız',

];
