<?php

return [

    'confirmation' => 'ئایا دڵنیای لە کردنی ئەم کارە؟',

    'actions' => [

        'cancel' => [
            'label' => 'رەتکردنەوە',
        ],

        'confirm' => [
            'label' => 'دلنیام',
        ],

        'submit' => [
            'label' => 'ناردن',
        ],

    ],

];
