<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Ашиглах заавар',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
