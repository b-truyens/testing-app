{{ money($amount, $currency, $convert) }}
