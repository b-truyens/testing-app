<p
    {{ $attributes->class(['filament-header-subheading max-w-2xl tracking-tight text-gray-500']) }}
>
    {{ $slot }}
</p>
