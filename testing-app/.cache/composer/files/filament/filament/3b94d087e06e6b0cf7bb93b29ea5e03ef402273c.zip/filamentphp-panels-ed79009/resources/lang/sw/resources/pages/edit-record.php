<?php

return [

    'title' => 'Hariri :label',

    'breadcrumb' => 'Hariri',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Ghairi',
            ],

            'save' => [
                'label' => 'Hifadhi mabadiliko',
            ],

        ],

        'tab' => [
            'label' => 'Hariri',
        ],

    ],

    'messages' => [
        'saved' => 'Imehifadhiwa',
    ],

];
