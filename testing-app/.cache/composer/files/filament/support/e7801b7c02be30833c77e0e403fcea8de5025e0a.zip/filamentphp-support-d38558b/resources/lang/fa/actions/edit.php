<?php

return [

    'single' => [

        'label' => 'ویرایش',

        'modal' => [

            'heading' => 'ویرایش :label',

            'actions' => [

                'save' => [
                    'label' => 'ذخیره',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'ذخیره شد',
        ],

    ],

];
