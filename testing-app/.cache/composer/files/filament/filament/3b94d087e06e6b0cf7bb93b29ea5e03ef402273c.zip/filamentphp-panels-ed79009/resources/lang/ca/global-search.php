<?php

return [

    'field' => [
        'label' => 'Cerca global',
        'placeholder' => 'Cerca',
    ],

    'no_results_message' => 'No s\'han trobat resultats.',

];
