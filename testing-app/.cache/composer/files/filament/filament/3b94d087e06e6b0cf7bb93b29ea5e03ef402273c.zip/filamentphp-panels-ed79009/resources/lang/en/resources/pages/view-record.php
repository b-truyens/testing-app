<?php

return [

    'title' => 'View :label',

    'breadcrumb' => 'View',

    'form' => [

        'tab' => [
            'label' => 'View',
        ],

    ],

];
