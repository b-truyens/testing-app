<?php

return [

    'title' => 'Ikusi :label',

    'breadcrumb' => 'Ikusi',

    'form' => [

        'tab' => [
            'label' => 'Ikusi',
        ],

    ],

];
