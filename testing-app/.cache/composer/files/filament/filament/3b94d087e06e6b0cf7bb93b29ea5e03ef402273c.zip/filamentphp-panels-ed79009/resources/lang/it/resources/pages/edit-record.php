<?php

return [

    'title' => 'Modifica :label',

    'breadcrumb' => 'Modifica',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Annulla',
            ],

            'save' => [
                'label' => 'Salva',
            ],

        ],

        'tab' => [
            'label' => 'Modifica',
        ],

    ],

    'messages' => [
        'saved' => 'Salvato',
    ],

];
