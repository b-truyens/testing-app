<?php

return [

    'single' => [

        'label' => 'Atașare',

        'modal' => [

            'heading' => 'Atașare :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Înregistrare',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Atașare',
                ],

                'attach_another' => [
                    'label' => 'Atașați și atașați altul',
                ],

            ],

        ],

        'messages' => [
            'attached' => 'Atașat cu succes',
        ],

    ],

];
