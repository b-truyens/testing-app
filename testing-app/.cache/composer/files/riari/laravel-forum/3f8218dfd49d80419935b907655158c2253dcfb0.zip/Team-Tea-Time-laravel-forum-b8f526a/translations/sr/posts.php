<?php

return [

    'actions' => 'Akcije nad objavom',
    'created' => 'Objava kreirana',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Objava izbrisana|Objave izbrisane',
    'edit' => 'Izmeni objavu',
    'last' => 'Poslednja objava',
    'perma_deleted' => 'Objava trajno izbrisana|Objave trajno izbrisane',
    'post' => 'Objava|Objave',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Objava vraćena|Objave vraćene',
    'select_all' => 'Select all posts',
    'updated' => 'Objava izmenjena|Objave izmenjene',
    'view' => 'Vidi objavu',
    'your_post' => 'Vaša objava',

];
