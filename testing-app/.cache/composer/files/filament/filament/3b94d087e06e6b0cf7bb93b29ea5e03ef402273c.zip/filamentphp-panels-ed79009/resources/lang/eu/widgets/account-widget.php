<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Irten',
        ],

    ],

    'welcome' => 'Ongi etorri, :user',

];
