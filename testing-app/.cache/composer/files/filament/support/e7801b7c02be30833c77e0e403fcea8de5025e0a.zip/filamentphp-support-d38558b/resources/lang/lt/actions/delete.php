<?php

return [

    'single' => [

        'label' => 'Ištrinti',

        'modal' => [

            'heading' => 'Ištrinti :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ištrinti',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Ištrinta',
        ],

    ],

    'multiple' => [

        'label' => 'Ištrinti pažymėtus',

        'modal' => [

            'heading' => 'Ištrinti pažymėtą :label',

            'actions' => [

                'delete' => [
                    'label' => 'Ištrinti',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Ištrinta',
        ],

    ],

];
