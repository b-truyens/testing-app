<?php

return [

    'direction' => 'বাম থেকে ডানে',

    'buttons' => [

        'dark_mode' => [
            'label' => 'ডার্ক মোড',
        ],

        'database_notifications' => [
            'label' => 'বিজ্ঞপ্তি খুলুন',
        ],

        'light_mode' => [
            'label' => 'লাইট মোড',
        ],

        'logout' => [
            'label' => 'সাইন আউট',
        ],

        'user_menu' => [
            'label' => 'ব্যবহার সূচী',
        ],

    ],

];
