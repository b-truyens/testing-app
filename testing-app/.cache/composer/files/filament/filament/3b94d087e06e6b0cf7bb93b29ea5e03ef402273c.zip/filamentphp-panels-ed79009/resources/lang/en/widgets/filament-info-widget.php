<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Documentation',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
