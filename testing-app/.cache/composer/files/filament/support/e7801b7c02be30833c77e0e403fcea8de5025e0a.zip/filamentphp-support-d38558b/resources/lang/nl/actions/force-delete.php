<?php

return [

    'single' => [

        'label' => 'Geforceerd verwijderen',

        'modal' => [

            'heading' => ':Label geforceerd verwijderen',

            'actions' => [

                'delete' => [
                    'label' => 'Verwijderen',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Verwijderd',
        ],

    ],

    'multiple' => [

        'label' => 'Geselecteerde geforceerd verwijderen',

        'modal' => [

            'heading' => 'Geselecteerde :label geforceerd verwijderen',

            'actions' => [

                'delete' => [
                    'label' => 'Verwijderen',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Verwijderd',
        ],

    ],

];
