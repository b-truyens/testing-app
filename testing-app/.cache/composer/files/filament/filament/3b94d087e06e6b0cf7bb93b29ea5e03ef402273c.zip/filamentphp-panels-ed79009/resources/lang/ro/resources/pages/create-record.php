<?php

return [

    'title' => 'Creare :label',

    'breadcrumb' => 'Creare',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Anulare',
            ],

            'create' => [
                'label' => 'Creare',
            ],

            'create_another' => [
                'label' => 'Creați și creați altul',
            ],

        ],

    ],

    'messages' => [
        'created' => 'Creat cu succes',
    ],

];
