<?php

return [

    'single' => [

        'label' => 'Elkartu',

        'modal' => [

            'heading' => 'Elkartu :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Erregistroa',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Elkartu',
                ],

                'associate_another' => [
                    'label' => 'Elkartu eta beste bat elkartu',
                ],

            ],

        ],

        'messages' => [
            'associated' => 'Elkartuta',
        ],

    ],

];
