<x-tables::icon-button
    icon="heroicon-o-dots-vertical"
    :label="__('tables::table.buttons.open_actions.label')"
    x-cloak
    {{ $attributes->class(['filament-tables-bulk-actions-trigger']) }}
/>
