<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Вийти',
        ],

    ],

    'welcome' => 'Вітаємо, :user',

];
