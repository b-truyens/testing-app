<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'مستندات',
        ],

        'visit_github' => [
            'label' => 'گیت‌هاب',
        ],

    ],

];
