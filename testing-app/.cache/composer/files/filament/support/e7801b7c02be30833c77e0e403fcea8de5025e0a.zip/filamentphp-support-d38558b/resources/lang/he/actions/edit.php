<?php

return [

    'single' => [

        'label' => 'ערוך',

        'modal' => [

            'heading' => 'ערך את :label',

            'actions' => [

                'save' => [
                    'label' => 'שמור שינויים',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'נשמר',
        ],

    ],

];
