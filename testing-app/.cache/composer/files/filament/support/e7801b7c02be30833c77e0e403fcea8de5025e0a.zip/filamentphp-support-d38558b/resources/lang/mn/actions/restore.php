<?php

return [

    'single' => [

        'label' => 'Сэргээх',

        'modal' => [

            'heading' => 'Сэргээх :label',

            'actions' => [

                'restore' => [
                    'label' => 'Сэргээх',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Сэргээв',
        ],

    ],

    'multiple' => [

        'label' => 'Сонгосонг сэргээх',

        'modal' => [

            'heading' => 'Сэргээх :label',

            'actions' => [

                'restore' => [
                    'label' => 'Сэргээх',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Сэргээв',
        ],

    ],

];
