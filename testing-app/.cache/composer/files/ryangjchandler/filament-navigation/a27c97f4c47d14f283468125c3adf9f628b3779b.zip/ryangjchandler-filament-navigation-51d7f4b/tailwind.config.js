module.exports = {
    content: ["./resources/views/**/*.blade.php"],
    darkMode: "class",
    important: ".filament-navigation",
    theme: {
        extend: {},
    },
    plugins: [],
    corePlugins: {
        preflight: false,
    },
};
