<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => '說明文件',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
