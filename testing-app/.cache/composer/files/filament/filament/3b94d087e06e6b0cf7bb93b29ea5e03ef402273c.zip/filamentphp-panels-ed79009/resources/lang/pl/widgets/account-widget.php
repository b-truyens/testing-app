<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Wyloguj się',
        ],

    ],

    'welcome' => 'Witaj, :user',

];
