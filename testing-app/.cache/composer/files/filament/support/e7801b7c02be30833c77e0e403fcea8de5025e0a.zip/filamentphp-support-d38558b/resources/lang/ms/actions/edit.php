<?php

return [

    'single' => [

        'label' => 'Sunting',

        'modal' => [

            'heading' => 'Sunting :label',

            'actions' => [

                'save' => [
                    'label' => 'Simpan',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Disimpan',
        ],

    ],

];
