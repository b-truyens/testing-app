<?php

return [

    'single' => [

        'label' => 'تکثیر',

        'modal' => [

            'heading' => 'تکثیر :label',

            'actions' => [

                'replicate' => [
                    'label' => 'تکثیر',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'رکورد تکثیر شد',
        ],

    ],

];
