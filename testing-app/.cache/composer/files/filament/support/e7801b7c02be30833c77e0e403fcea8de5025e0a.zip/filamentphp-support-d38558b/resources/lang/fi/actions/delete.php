<?php

return [

    'single' => [

        'label' => 'Poista',

        'modal' => [

            'heading' => 'Poista :label',

            'actions' => [

                'delete' => [
                    'label' => 'Poista',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Poistettu',
        ],

    ],

    'multiple' => [

        'label' => 'Poista valitut',

        'modal' => [

            'heading' => 'Poista valitut :label',

            'actions' => [

                'delete' => [
                    'label' => 'Poista',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Poistettu',
        ],

    ],

];
