<?php

return [

    'single' => [

        'label' => 'リストア',

        'modal' => [

            'heading' => ':labelリストア',

            'actions' => [

                'restore' => [
                    'label' => 'リストア',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'リストアしました',
        ],

    ],

    'multiple' => [

        'label' => '選択のリストア',

        'modal' => [

            'heading' => '選択した:labelをリストア',

            'actions' => [

                'restore' => [
                    'label' => 'リストア',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'リストアしました',
        ],

    ],

];
