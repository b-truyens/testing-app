<?php

return [

    'title' => ':label ansehen',

    'breadcrumb' => 'Ansehen',

    'form' => [

        'tab' => [
            'label' => 'Ansehen',
        ],

    ],

];
