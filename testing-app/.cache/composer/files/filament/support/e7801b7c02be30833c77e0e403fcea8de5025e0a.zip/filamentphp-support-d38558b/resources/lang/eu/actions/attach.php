<?php

return [

    'single' => [

        'label' => 'Erantsi',

        'modal' => [

            'heading' => 'Erantsi :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Erregistroa',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Erantsi',
                ],

                'attach_another' => [
                    'label' => 'Erantsi eta beste bat erantsi',
                ],

            ],

        ],

        'messages' => [
            'attached' => 'Erantsita',
        ],

    ],

];
