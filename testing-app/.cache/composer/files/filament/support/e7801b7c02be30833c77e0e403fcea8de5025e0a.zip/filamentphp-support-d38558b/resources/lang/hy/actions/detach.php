<?php

return [

    'single' => [

        'label' => 'Անջատել',

        'modal' => [

            'heading' => 'Անջատել :label',

            'actions' => [

                'detach' => [
                    'label' => 'Անջատել',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Անջատվել է',
        ],

    ],

    'multiple' => [

        'label' => 'Անջատել ընտրվածը',

        'modal' => [

            'heading' => 'Անջատել ընտրված :label',

            'actions' => [

                'detach' => [
                    'label' => 'Անջատել ընտրվածը',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Անջատվել է',
        ],

    ],

];
