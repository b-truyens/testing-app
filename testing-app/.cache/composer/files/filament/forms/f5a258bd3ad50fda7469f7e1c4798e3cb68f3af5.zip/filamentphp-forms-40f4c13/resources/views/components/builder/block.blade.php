<div
    {{ $attributes->merge($getExtraAttributes())->class(['filament-forms-builder-component-block py-8']) }}
>
    {{ $getChildComponentContainer() }}
</div>
