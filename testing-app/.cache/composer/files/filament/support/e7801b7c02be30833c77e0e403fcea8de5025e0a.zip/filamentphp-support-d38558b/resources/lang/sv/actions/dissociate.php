<?php

return [

    'single' => [

        'label' => 'Dissociera',

        'modal' => [

            'heading' => 'Dissociera :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociera',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Dissocierad',
        ],

    ],

    'multiple' => [

        'label' => 'Dissociera valda',

        'modal' => [

            'heading' => 'Dissociera valda :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissociera valda',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Dissocierade',
        ],

    ],

];
