<?php

return [

    'single' => [

        'label' => 'تعديل',

        'modal' => [

            'heading' => 'تعديل :label',

            'actions' => [

                'save' => [
                    'label' => 'حفظ',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'تم الحفظ',
        ],

    ],

];
