<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dokumentazioa',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
