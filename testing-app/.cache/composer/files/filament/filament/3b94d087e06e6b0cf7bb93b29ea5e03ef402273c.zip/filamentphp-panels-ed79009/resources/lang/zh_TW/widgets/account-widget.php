<?php

return [

    'buttons' => [

        'logout' => [
            'label' => '登出',
        ],

    ],

    'welcome' => '歡迎，:user',

];
