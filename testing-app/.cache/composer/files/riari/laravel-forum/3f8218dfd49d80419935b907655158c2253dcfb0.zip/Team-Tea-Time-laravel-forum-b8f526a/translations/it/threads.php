<?php

return [

    'actions' => 'Azioni discussione',
    'created' => 'Discussione creata',
    'delete' => 'Elimina questa discussione',
    'deleted' => 'Discussione eliminata|Discussioni eliminate',
    'lock' => 'Blocca',
    'locked' => 'Bloccata',
    'marked_read' => 'Tutte le discussioni sono marcate come lette',
    'new_thread' => 'Nuova discussione',
    'new_updated' => 'Discussioni nuove ed aggiornate',
    'newest' => 'Discussione più recente',
    'none_found' => 'Nessuna discussione trovata',
    'perma_delete' => 'Permanently delete thread|Permanently delete threads',
    'perma_deleted' => 'Discussione eliminata in modo permanente|Discussioni eliminate definitivamente',
    'pin' => 'Importante',
    'pinned' => 'Resa importante',
    'post_the_first' => 'Rispondi per primo!',
    'restored' => 'Discussione ripristinata|Discussioni ripristinate',
    'thread' => 'Discussione|Discussioni',
    'updated' => 'Discussione aggiornato|Discussioni aggiornate',
    'unlock' => 'Sblocca',
    'unpin' => 'Non importante',
    'view' => 'Vedi discussione',

];
