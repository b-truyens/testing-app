<?php

return [

    'category_threads_enabled' => 'La categoría debe tener hilos habilitados.',
    'category_has_no_threads' => 'La categoría no debe contener hilos.',
    'category_is_empty' => 'La categoría debe estar vacía.',

];
