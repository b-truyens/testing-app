<?php

return [

    'actions' => 'Akcije nad temom',
    'created' => 'Tema kreirana',
    'delete' => 'Izbriši ovu temu',
    'deleted' => 'Tema izbrisana|Teme izbrisane',
    'lock' => 'Zaključaj',
    'locked' => 'Zaključano',
    'marked_read' => 'Sve teme su označene kao pročitane',
    'new_thread' => 'Nova tema',
    'new_updated' => 'Nove i izmenjene teme',
    'newest' => 'Najnovija tema',
    'none_found' => 'Teme nisu nadđene',
    'perma_delete' => 'Permanently delete thread|Permanently delete threads',
    'perma_deleted' => 'Tema trajno izbrisana|Teme trajno izbrisane',
    'pin' => 'Zakači',
    'pinned' => 'Zakačeno',
    'post_the_first' => 'Objavi prvu!',
    'restored' => 'Tema povraćena|Teme povraćene',
    'thread' => 'Tema|Teme',
    'updated' => 'Tema izmenjena|Teme izmenjene',
    'unlock' => 'Otključaj',
    'unpin' => 'Otkači',
    'view' => 'Vidi temu',

];
