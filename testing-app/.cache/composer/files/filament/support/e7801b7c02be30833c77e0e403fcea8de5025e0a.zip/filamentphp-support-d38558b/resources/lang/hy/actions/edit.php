<?php

return [

    'single' => [

        'label' => 'Խմբագրել',

        'modal' => [

            'heading' => 'Խմբագրել :label',

            'actions' => [

                'save' => [
                    'label' => 'Պահպանել',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Պահպանվել է',
        ],

    ],

];
