<?php

return [

    'field' => [
        'label' => 'Глобал хайлт',
        'placeholder' => 'хайлт',
    ],

    'no_results_message' => 'Илэрц олдсонгүй.',

];
