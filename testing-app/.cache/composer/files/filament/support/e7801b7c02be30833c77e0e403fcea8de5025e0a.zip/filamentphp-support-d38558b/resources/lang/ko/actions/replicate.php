<?php

return [

    'single' => [

        'label' => '복사',

        'modal' => [

            'heading' => ':label 복사',

            'actions' => [

                'replicate' => [
                    'label' => '복사',
                ],

            ],

        ],

        'messages' => [
            'replicated' => '복사됨',
        ],

    ],

];
