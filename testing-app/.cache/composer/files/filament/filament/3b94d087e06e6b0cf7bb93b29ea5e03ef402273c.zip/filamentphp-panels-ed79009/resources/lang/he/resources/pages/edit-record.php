<?php

return [

    'title' => 'ערוך :label',

    'breadcrumb' => 'עריכה',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'ביטול',
            ],

            'save' => [
                'label' => 'שמור שינויים',
            ],

        ],

        'tab' => [
            'label' => 'עריכה',
        ],

    ],

    'messages' => [
        'saved' => 'נשמר בהצלחה',
    ],

];
