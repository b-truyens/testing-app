<?php

return [

    'title' => 'Rediģēt :label',

    'breadcrumb' => 'Rediģēt',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Atcelt',
            ],

            'save' => [
                'label' => 'Saglabāt izmaiņas',
            ],

        ],

        'tab' => [
            'label' => 'Rediģēt',
        ],

    ],

    'messages' => [
        'saved' => 'Saglabāts',
    ],

];
