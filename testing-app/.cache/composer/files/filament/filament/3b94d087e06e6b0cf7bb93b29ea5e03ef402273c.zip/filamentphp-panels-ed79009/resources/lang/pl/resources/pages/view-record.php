<?php

return [

    'title' => 'Podgląd :label',

    'breadcrumb' => 'Podgląd',

    'form' => [

        'tab' => [
            'label' => 'Podgląd',
        ],

    ],

];
