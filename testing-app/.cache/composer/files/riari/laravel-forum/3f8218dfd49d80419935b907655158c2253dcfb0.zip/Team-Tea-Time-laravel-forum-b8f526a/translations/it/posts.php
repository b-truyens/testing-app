<?php

return [

    'actions' => 'Azioni post',
    'created' => 'Post creato',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Post eliminato|Post eliminati',
    'edit' => 'Modifica post',
    'last' => 'Ultimo post',
    'perma_deleted' => 'Post eliminati in modo permanente|Post eliminati definitivamente',
    'post' => 'Post|Post',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Post ripristinato|Post ripristinati',
    'select_all' => 'Select all posts',
    'updated' => 'Post aggiornato|Post aggiornati',
    'view' => 'Vedi post',
    'your_post' => 'Il tuo post',

];
