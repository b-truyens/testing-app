<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'ထွက်မည်',
        ],

    ],

    'welcome' => 'ကြိုဆိုပါတယ် :user',

];
