<?php

return [

    'single' => [

        'label' => 'Hariri',

        'modal' => [

            'heading' => 'Hariri :label',

            'actions' => [

                'save' => [
                    'label' => 'Hifadhi mabadiliko',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Imehifadhiwa',
        ],

    ],

];
