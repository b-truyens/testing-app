<?php

return [

    'title' => 'Ver :label',

    'breadcrumb' => 'Ver',

    'form' => [

        'tab' => [
            'label' => 'Ver',
        ],

    ],

];
