<?php

return [

    'title' => ':Label aanmaken',

    'breadcrumb' => 'Aanmaken',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Annuleren',
            ],

            'create' => [
                'label' => 'Aanmaken',
            ],

            'create_another' => [
                'label' => 'Aanmaken & nieuwe aanmaken',
            ],

        ],

    ],

    'messages' => [
        'created' => 'Aangemaakt',
    ],

];
