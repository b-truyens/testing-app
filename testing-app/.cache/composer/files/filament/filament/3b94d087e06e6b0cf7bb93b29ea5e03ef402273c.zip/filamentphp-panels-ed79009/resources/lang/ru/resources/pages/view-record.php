<?php

return [

    'title' => 'Просмотр :label',

    'breadcrumb' => 'Просмотр',

    'form' => [

        'tab' => [
            'label' => 'Просмотр',
        ],

    ],

];
