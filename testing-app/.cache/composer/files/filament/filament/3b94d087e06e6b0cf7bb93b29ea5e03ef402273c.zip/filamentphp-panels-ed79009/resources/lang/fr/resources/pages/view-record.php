<?php

return [

    'title' => 'Afficher :label',

    'breadcrumb' => 'Afficher',

    'form' => [

        'tab' => [
            'label' => 'Afficher',
        ],

    ],

];
