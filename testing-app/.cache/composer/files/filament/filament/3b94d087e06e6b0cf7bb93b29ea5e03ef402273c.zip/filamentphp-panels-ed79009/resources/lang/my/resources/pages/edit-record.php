<?php

return [

    'title' => ':label ကိုတည်းဖြတ်ပါ',

    'breadcrumb' => 'တည်းဖြတ်ပါ',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'မလုပ်တော့ပါ',
            ],

            'save' => [
                'label' => 'မှတ်ပါ',
            ],

        ],

    ],

    'messages' => [
        'saved' => 'သိမ်းဆည်းထားသည်',
    ],

];
