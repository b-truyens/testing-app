<?php

return [

    'title' => 'Guarda :label',

    'breadcrumb' => 'Guarda',

    'form' => [

        'tab' => [
            'label' => 'Guarda',
        ],

    ],

];
