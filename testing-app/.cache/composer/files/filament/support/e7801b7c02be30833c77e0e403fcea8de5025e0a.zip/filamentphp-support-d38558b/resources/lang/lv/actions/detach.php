<?php

return [

    'single' => [

        'label' => 'Noņemt',

        'modal' => [

            'heading' => 'Noņemt :label',

            'actions' => [

                'detach' => [
                    'label' => 'Noņemt',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Noņemts',
        ],

    ],

    'multiple' => [

        'label' => 'Noņemt atzīmētos',

        'modal' => [

            'heading' => 'Noņemt atzīmēto :label',

            'actions' => [

                'detach' => [
                    'label' => 'Noņemt',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Noņemti',
        ],

    ],

];
