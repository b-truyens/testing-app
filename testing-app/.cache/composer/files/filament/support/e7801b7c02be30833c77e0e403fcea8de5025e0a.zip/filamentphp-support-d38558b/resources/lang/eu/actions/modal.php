<?php

return [

    'confirmation' => 'Ziur zaude hau egin nahi duzula?',

    'actions' => [

        'cancel' => [
            'label' => 'Ezeztatu',
        ],

        'confirm' => [
            'label' => 'Baieztatu',
        ],

        'submit' => [
            'label' => 'Bidali',
        ],

    ],

];
