<?php

return [

    'actions' => 'Aksi pada Thread',
    'created' => 'Thread dibuat',
    'delete' => 'Hapus thread|Hapus thread',
    'deleted' => 'Thread dihapus|Thread dihapus',
    'lock' => 'Kunci thread|Kunci thread',
    'locked' => 'Thread dikunci|Thread dikunci',
    'marked_read' => 'Thread baru/terbaru di :category telah ditandai sebagai telah dibaca',
    'new_thread' => 'Thread baru',
    'newest' => 'Thread terbaru',
    'none_found' => 'Tidak ada thread yang ditemukan',
    'perma_delete' => 'Hapus secara permanen|Hapus secara permanen',
    'perma_deleted' => 'Thread dihapus secara permanen|Thread dihapus secara permanen',
    'pin' => 'Pin',
    'pinned' => 'Thread dipin',
    'post_the_first' => 'Buat thread pertama!',
    'recent' => 'Thread terbaru',
    'restored' => 'Thread dipulihkan|Thread dipulihkan',
    'select_all' => 'Pilih semua thread',
    'thread' => 'Thread|Thread',
    'updated' => 'Thread diperbarui|Thread diperbarui',
    'unlock' => 'Buka thread',
    'unpin' => 'Unpin',
    'unread_updated' => 'Unread & perbarui threads',
    'view' => 'Lihat thread',

];
