<?php

return [

    'category_threads_enabled' => 'Pembuatan thread baru di kategori ini telah diaktifkan',
    'category_has_no_threads' => 'Pembuatan thread baru di kategori ini telah dinonaktifkan',
    'category_is_empty' => 'Kategori ini kosong',

];
