<?php

return [

    'single' => [

        'label' => 'ساختن :label',

        'modal' => [

            'heading' => 'ساختن :label',

            'actions' => [

                'create' => [
                    'label' => 'ساختن',
                ],

                'create_another' => [
                    'label' => 'ساختن و ساختن یکی دیگر',
                ],

            ],

        ],

        'messages' => [
            'created' => 'ساخته شد',
        ],

    ],

];
