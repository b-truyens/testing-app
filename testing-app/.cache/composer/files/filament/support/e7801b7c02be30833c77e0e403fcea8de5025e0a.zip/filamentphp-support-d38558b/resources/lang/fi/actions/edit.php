<?php

return [

    'single' => [

        'label' => 'Muokkaa',

        'modal' => [

            'heading' => 'Muokkaa :label',

            'actions' => [

                'save' => [
                    'label' => 'Tallenna',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Tallennettu',
        ],

    ],

];
