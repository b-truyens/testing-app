<?php

return [

    'single' => [

        'label' => 'Detașare',

        'modal' => [

            'heading' => 'Detașare :label',

            'actions' => [

                'detach' => [
                    'label' => 'Detașare',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Detașat cu succes',
        ],

    ],

    'multiple' => [

        'label' => 'Detașați înregistrările selectate',

        'modal' => [

            'heading' => 'Detașați :label selectate',

            'actions' => [

                'detach' => [
                    'label' => 'Detașați înregistrările selectate',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Detașat cu succes',
        ],

    ],

];
