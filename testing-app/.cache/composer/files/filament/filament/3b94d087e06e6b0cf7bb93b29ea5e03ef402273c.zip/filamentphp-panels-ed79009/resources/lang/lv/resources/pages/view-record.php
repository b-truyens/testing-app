<?php

return [

    'title' => 'Skatīt :label',

    'breadcrumb' => 'Skatīt',

    'form' => [

        'tab' => [
            'label' => 'Skatīt',
        ],

    ],

];
