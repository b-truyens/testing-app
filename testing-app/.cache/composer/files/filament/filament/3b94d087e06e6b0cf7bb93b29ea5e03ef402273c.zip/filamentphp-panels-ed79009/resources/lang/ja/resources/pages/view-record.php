<?php

return [

    'title' => ':label詳細',

    'breadcrumb' => '詳細',

    'form' => [

        'tab' => [
            'label' => '詳細',
        ],

    ],

];
