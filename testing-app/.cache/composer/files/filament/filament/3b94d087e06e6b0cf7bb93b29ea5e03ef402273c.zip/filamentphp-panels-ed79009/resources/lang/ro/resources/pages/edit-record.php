<?php

return [

    'title' => 'Editare :label',

    'breadcrumb' => 'Editare',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Anulare',
            ],

            'save' => [
                'label' => 'Salvare',
            ],

        ],

        'tab' => [
            'label' => 'Editare',
        ],

    ],

    'messages' => [
        'saved' => 'Salvat cu succes',
    ],

];
