<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dokumentacija',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
