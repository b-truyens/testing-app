<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Документация',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
