<?php

return [

    'single' => [

        'label' => 'Forza eliminazione',

        'modal' => [

            'heading' => 'Forza eliminazione :label',

            'actions' => [

                'delete' => [
                    'label' => 'Elimina',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Eliminato',
        ],

    ],

    'multiple' => [

        'label' => 'Elimina forzatamente selezionati',

        'modal' => [

            'heading' => 'Elimina forzatamente selezionati :label',

            'actions' => [

                'delete' => [
                    'label' => 'Elimina',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Eliminati',
        ],

    ],

];
