<?php

return [

    'single' => [

        'label' => 'İlişkilendir',

        'modal' => [

            'heading' => ':label İlişkilendir',

            'fields' => [

                'record_id' => [
                    'label' => 'Kayıt',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'İlişkilendir',
                ],

                'associate_another' => [
                    'label' => 'İlişkilendir ve başka bir taneye başla',
                ],

            ],

        ],

        'messages' => [
            'associated' => 'İlişkilendirildi',
        ],

    ],

];
