<?php

return [

    'confirmation' => 'Estàs segur/a que vols fer aquesta acció?',

    'actions' => [

        'cancel' => [
            'label' => 'Cancel·lar',
        ],

        'confirm' => [
            'label' => 'Confirmar',
        ],

        'submit' => [
            'label' => 'Enviar',
        ],

    ],

];
