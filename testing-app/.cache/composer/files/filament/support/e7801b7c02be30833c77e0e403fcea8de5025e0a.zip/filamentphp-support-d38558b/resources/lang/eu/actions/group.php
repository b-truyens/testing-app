<?php

return [

    'trigger' => [
        'label' => 'Akzioak',
    ],

];
