<?php

return [

    'actions' => 'Acțiuni de discuții',
    'created' => 'Discuție creată',
    'delete' => 'Șterge această discuție',
    'deleted' => 'Discuție ștearsă|Discuții eliminat',
    'lock' => 'Bloca',
    'locked' => 'Blocat',
    'marked_read' => 'Toate discuțiile au fost marcate ca citite',
    'new_thread' => 'Discuție nouă',
    'new_updated' => 'Discuții noi și actualizate',
    'newest' => 'Cea mai nouă discuție',
    'none_found' => 'Nicio discuție găsită',
    'perma_delete' => 'Permanently delete thread|Permanently delete threads',
    'perma_deleted' => 'Discuție șters definitiv|Discuții șters definitiv',
    'pin' => 'Fixa',
    'pinned' => 'Fixate',
    'post_the_first' => 'Începe prima discuție!',
    'restored' => 'Discuție restaurat|Discuții restaurat',
    'thread' => 'Discuție|Discuții',
    'updated' => 'Discuție actualizată|Discuții actualizat',
    'unlock' => 'Deschide',
    'unpin' => 'Dezlega',
    'view' => 'Vezi discuție',

];
