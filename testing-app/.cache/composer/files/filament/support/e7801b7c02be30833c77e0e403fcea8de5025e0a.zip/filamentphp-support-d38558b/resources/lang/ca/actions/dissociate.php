<?php

return [

    'single' => [

        'label' => 'Desvincular',

        'modal' => [

            'heading' => 'Desvincular :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Desvincular',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Desvinculat',
        ],

    ],

    'multiple' => [

        'label' => 'Desvincular seleccionats',

        'modal' => [

            'heading' => 'Desvincular :label seleccionats',

            'actions' => [

                'dissociate' => [
                    'label' => 'Desvincular',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Desvinculats',
        ],

    ],

];
