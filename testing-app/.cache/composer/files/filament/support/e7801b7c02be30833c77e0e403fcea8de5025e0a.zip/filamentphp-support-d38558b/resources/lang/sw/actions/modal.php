<?php

return [

    'confirmation' => 'Unahakika unataka kufanya hili?',

    'actions' => [

        'cancel' => [
            'label' => 'Ghairi',
        ],

        'confirm' => [
            'label' => 'Thibitisha',
        ],

        'submit' => [
            'label' => 'Wasilisha',
        ],

    ],

];
