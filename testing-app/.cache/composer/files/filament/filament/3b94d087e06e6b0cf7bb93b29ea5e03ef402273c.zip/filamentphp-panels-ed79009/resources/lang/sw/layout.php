<?php

return [

    'direction' => 'ltr',

    'buttons' => [

        'dark_mode' => [
            'label' => 'Geuza hali ya giza',
        ],

        'database_notifications' => [
            'label' => 'Fungua arifa',
        ],

        'light_mode' => [
            'label' => 'Geuza hali ya mwanga',
        ],

        'logout' => [
            'label' => 'Toka',
        ],

        'user_menu' => [
            'label' => 'Menyu ya Mtumiaji',
        ],

    ],

];
