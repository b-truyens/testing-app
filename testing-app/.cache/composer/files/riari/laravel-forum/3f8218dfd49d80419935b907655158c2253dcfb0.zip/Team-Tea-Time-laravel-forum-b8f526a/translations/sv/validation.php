<?php

return [

    'category_threads_enabled' => 'Kategorin måste ha trådar aktiverade.',
    'category_has_no_threads' => 'Kategorin får inte innehålla ämnen.',
    'category_is_empty' => 'Kategorin måste vara tom.',

];
