<?php

return [

    'single' => [

        'label' => 'Sil',

        'modal' => [

            'heading' => ':label sil',

            'actions' => [

                'delete' => [
                    'label' => 'Sil',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Silindi',
        ],

    ],

    'multiple' => [

        'label' => 'Seçiliyi sil',

        'modal' => [

            'heading' => ':label seçiliyi sil',

            'actions' => [

                'delete' => [
                    'label' => 'Sil',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Silindi',
        ],

    ],

];
