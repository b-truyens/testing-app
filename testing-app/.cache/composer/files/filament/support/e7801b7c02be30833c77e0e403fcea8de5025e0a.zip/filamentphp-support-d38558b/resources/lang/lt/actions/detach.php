<?php

return [

    'single' => [

        'label' => 'Atskirti',

        'modal' => [

            'heading' => 'Atskirti :label',

            'actions' => [

                'detach' => [
                    'label' => 'Atskirti',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Atskirta',
        ],

    ],

    'multiple' => [

        'label' => 'Atskirti pasirinktą',

        'modal' => [

            'heading' => 'Atskirti pasirinktą :label',

            'actions' => [

                'detach' => [
                    'label' => 'Atskirti',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Atskirta',
        ],

    ],

];
