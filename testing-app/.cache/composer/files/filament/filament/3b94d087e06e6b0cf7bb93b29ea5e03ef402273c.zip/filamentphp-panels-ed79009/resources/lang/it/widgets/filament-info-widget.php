<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Documentazione',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
