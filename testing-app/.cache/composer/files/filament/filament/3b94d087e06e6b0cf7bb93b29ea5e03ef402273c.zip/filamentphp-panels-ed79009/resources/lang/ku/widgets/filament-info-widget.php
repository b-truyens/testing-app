<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'پەڕگەی یارماتیدەر',
        ],

        'visit_github' => [
            'label' => 'گیت هەب',
        ],

    ],

];
