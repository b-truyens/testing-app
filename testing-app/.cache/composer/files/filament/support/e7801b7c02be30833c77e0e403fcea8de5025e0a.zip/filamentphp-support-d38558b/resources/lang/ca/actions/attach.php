<?php

return [

    'single' => [

        'label' => 'Adjuntar',

        'modal' => [

            'heading' => 'Adjuntar :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Registre',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Adjuntar',
                ],

                'attach_another' => [
                    'label' => 'Adjuntar & adjuntar un altre',
                ],

            ],

        ],

        'messages' => [
            'attached' => 'Adjuntat',
        ],

    ],

];
