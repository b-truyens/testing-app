<?php

return [

    'single' => [

        'label' => 'Szerkesztés',

        'modal' => [

            'heading' => ':label szerkesztése',

            'actions' => [

                'save' => [
                    'label' => 'Mentés',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Mentve',
        ],

    ],

];
