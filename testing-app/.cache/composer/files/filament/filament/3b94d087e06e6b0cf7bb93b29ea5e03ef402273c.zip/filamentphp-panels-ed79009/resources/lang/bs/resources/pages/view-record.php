<?php

return [

    'title' => 'Pogled :label',

    'breadcrumb' => 'Pogled',

    'form' => [

        'tab' => [
            'label' => 'Pogled',
        ],

    ],

];
