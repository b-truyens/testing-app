<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'ব্যবহার গাইড',
        ],

        'visit_github' => [
            'label' => 'গিটহাব',
        ],

    ],

];
