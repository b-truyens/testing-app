<?php

return [

    'title' => 'Vis :label',

    'breadcrumb' => 'Vis',

    'form' => [

        'tab' => [
            'label' => 'Vis',
        ],

    ],

];
