<?php

return [

    'single' => [

        'label' => 'Irrota',

        'modal' => [

            'heading' => 'Irrota :label',

            'actions' => [

                'detach' => [
                    'label' => 'Irrota',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Irrotettu',
        ],

    ],

    'multiple' => [

        'label' => 'Irrota valitut',

        'modal' => [

            'heading' => 'Irrota valitut :label',

            'actions' => [

                'detach' => [
                    'label' => 'Irrota valitut',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Irrotettu',
        ],

    ],

];
