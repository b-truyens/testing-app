<?php

return [

    'actions' => 'Acciones Discusión',
    'created' => 'Discusión creada',
    'delete' => 'Eliminar esta discusión',
    'deleted' => 'Discusión eliminada|Discusiones eliminada',
    'lock' => 'Cerrar',
    'locked' => 'Cerrado',
    'marked_read' => 'Todas las discusiones han sido marcadas como leidas',
    'new_thread' => 'Nueva discusión',
    'new_updated' => 'Discusiones nuevas y actualizadas',
    'newest' => 'Discusiones nuevas',
    'none_found' => 'No se encontraron discusiones',
    'perma_delete' => 'Permanently delete thread|Permanently delete threads',
    'perma_deleted' => 'Discusión eliminará de forma permanente|Discusiones eliminarán de forma permanente',
    'post_the_first' => 'Crea la priméra!',
    'pin' => 'Sujetar',
    'pinned' => 'Pegado',
    'restored' => 'Discusión restaurado|Discusiones restaurado',
    'thread' => 'Discusión|Discusiones',
    'updated' => 'Discusion actualizada|Discusiones actualizada',
    'unlock' => 'Abrir cerradura',
    'unpin' => 'Desabrochar',
    'unread_updated' => 'Unread & updated threads',
    'view' => 'Ver tema',

];
