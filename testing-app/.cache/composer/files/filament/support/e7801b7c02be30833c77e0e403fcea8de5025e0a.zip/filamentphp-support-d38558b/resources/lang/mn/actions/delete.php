<?php

return [

    'single' => [

        'label' => 'Устгах',

        'modal' => [

            'heading' => 'Устгах :label',

            'actions' => [

                'delete' => [
                    'label' => 'Устгах',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Устгасан',
        ],

    ],

    'multiple' => [

        'label' => 'Сонгосонг устгах',

        'modal' => [

            'heading' => 'Устгах :label',

            'actions' => [

                'delete' => [
                    'label' => 'Устгах',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Устгасан',
        ],

    ],

];
