<?php

return [

    'title' => 'Xem :label',

    'breadcrumb' => 'Xem',

    'form' => [

        'tab' => [
            'label' => 'Xem',
        ],

    ],

];
