<?php

return [

    'direction' => 'ltr',

    'buttons' => [

        'dark_mode' => [
            'label' => 'Միացնել մութ ռեժիմը',
        ],

        'light_mode' => [
            'label' => 'Միացնել լուսային ռեժիմը',
        ],

        'logout' => [
            'label' => 'Դուրս գալ',
        ],

        'user_menu' => [
            'label' => 'Օգտագործողի ընտրացանկ',
        ],

    ],

];
