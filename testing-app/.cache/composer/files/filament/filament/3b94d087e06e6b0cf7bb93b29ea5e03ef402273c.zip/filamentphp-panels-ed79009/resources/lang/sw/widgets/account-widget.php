<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Toka',
        ],

    ],

    'welcome' => 'Karibu, :user',

];
