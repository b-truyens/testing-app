<?php

return [

    'single' => [

        'label' => 'Repliker',

        'modal' => [

            'heading' => 'Repliker :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Repliker',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Replikeret',
        ],

    ],

];
