<?php

return [

    'actions' => 'Tråd åtgärder',
    'created' => 'Tråd skapad',
    'delete' => 'Radera den här tråden',
    'deleted' => 'Tråd utgår|Trådar utgår',
    'lock' => 'Lås',
    'locked' => 'Låst',
    'marked_read' => 'Alla trådar har markerats som lästa',
    'new_thread' => 'Ny tråd',
    'new_updated' => 'Nya & uppdaterade trådar',
    'newest' => 'Senaste tråden',
    'none_found' => 'Inga trådar hittades',
    'perma_delete' => 'Permanently delete thread|Permanently delete threads',
    'perma_deleted' => 'Tråd bort permanent|Ämnen bort permanent',
    'pin' => 'Pin',
    'pinned' => 'Pinnad',
    'post_the_first' => 'Skapa den första!',
    'restored' => 'Gäng restaurerade|Trådar restaurerade',
    'thread' => 'Tråd|Trådar',
    'updated' => 'Tråd uppdaterad|Trådar uppdaterade',
    'unlock' => 'Lås upp',
    'unpin' => 'Avpinna',
    'view' => 'Visa tråd',

];
