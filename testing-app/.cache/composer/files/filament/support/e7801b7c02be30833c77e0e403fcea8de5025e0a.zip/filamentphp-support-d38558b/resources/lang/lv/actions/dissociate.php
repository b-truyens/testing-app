<?php

return [

    'single' => [

        'label' => 'Atraut',

        'modal' => [

            'heading' => 'Atraut :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Atraut',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Atrauts',
        ],

    ],

    'multiple' => [

        'label' => 'Atraut atzīmētos',

        'modal' => [

            'heading' => 'Atraut atzīmēto :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Atraut',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Atrauti',
        ],

    ],

];
