<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'تسجيل الخروج',
        ],

    ],

    'welcome' => 'مرحبا, :user',

];
