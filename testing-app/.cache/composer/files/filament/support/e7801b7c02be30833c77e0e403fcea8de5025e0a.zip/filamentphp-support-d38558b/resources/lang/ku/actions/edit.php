<?php

return [

    'single' => [

        'label' => 'دەستکاری',

        'modal' => [

            'heading' => 'دەستکاری :label',

            'actions' => [

                'save' => [
                    'label' => 'هەڵگرتن',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'هەڵگیرا',
        ],

    ],

];
