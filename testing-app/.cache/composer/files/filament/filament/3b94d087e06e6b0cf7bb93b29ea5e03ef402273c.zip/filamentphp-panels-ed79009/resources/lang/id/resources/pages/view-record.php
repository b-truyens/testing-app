<?php

return [

    'title' => 'Lihat :label',

    'breadcrumb' => 'Lihat',

    'form' => [

        'tab' => [
            'label' => 'Lihat',
        ],

    ],

];
