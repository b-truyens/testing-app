<?php

return [

    'single' => [

        'label' => 'Sortu :label',

        'modal' => [

            'heading' => 'Sortu :label',

            'actions' => [

                'create' => [
                    'label' => 'Sortu',
                ],

                'create_another' => [
                    'label' => 'Sortu eta beste bat sortu',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Sortuta',
        ],

    ],

];
