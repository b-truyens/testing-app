<h1
    {{ $attributes->class(['filament-header-heading text-2xl font-bold tracking-tight']) }}
>
    {{ $slot }}
</h1>
