<?php

return [

    'field' => [
        'label' => 'Bilaketa globala',
        'placeholder' => 'Bilatu',
    ],

    'no_results_message' => 'Ez da emaitzarik aurkitu.',

];
