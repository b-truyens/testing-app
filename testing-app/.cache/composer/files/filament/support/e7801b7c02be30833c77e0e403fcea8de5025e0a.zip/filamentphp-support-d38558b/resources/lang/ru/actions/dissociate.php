<?php

return [

    'single' => [

        'label' => 'Отделить',

        'modal' => [

            'heading' => 'Отделено :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Отделить',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Отделено',
        ],

    ],

    'multiple' => [

        'label' => 'Отделить отмеченное',

        'modal' => [

            'heading' => 'Отделить отмеченное :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Отделить отмеченное',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Отделено',
        ],

    ],

];
