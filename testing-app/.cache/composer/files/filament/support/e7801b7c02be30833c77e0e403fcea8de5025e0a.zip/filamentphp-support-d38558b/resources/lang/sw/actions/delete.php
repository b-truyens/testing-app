<?php

return [

    'single' => [

        'label' => 'Futa',

        'modal' => [

            'heading' => 'Futa :label',

            'actions' => [

                'delete' => [
                    'label' => 'Futa',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Imefutwa',
        ],

    ],

    'multiple' => [

        'label' => 'Futa chaguo',

        'modal' => [

            'heading' => 'Futa chaguo :label',

            'actions' => [

                'delete' => [
                    'label' => 'Futa',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Imefutwa',
        ],

    ],

];
