<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dökümantasyon',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
