<?php

return [

    'single' => [

        'label' => 'سڕینەوەی بەهێز',

        'modal' => [

            'heading' => 'سڕینەوەی بەهێزی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'سڕدرایەوە',
        ],

    ],

    'multiple' => [

        'label' => 'سڕینەوەی بەهێز دیاری کرا',

        'modal' => [

            'heading' => 'سڕینەوەی بەهێز بۆ دیاریکراوی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'سڕدرایەوە',
        ],

    ],

];
