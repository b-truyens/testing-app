<?php

return [

    'single' => [

        'label' => 'Tenganisha',

        'modal' => [

            'heading' => 'Tenganisha :label',

            'actions' => [

                'detach' => [
                    'label' => 'Tenganisha',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Imetenganishwa',
        ],

    ],

    'multiple' => [

        'label' => 'Tenganisha chaguo',

        'modal' => [

            'heading' => 'Tenganisha chaguo :label',

            'actions' => [

                'detach' => [
                    'label' => 'Tenganisha',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Imetenganishwa',
        ],

    ],

];
