<?php

return [

    'actions' => 'Konu ayarları',
    'created' => 'Konu oluşturuldu',
    'delete' => 'Bu konuyu silindi',
    'deleted' => 'Konu silindi|Konular silindi',
    'lock' => 'Kilitle',
    'locked' => 'Kitlendi',
    'marked_read' => 'Tüm konular okundu olarak işaretlendi',
    'new_thread' => 'Yeni konu',
    'new_updated' => 'Yeni & güncellenen konular',
    'newest' => 'Son Konular',
    'none_found' => 'Konu bulunamadı',
    'perma_delete' => 'Permanently delete thread|Permanently delete threads',
    'perma_deleted' => 'Konu kalıcı olarak silindi|Konular kalıcı olarak silindi',
    'pin' => 'Sabitle',
    'pinned' => 'Sabitlendi',
    'post_the_first' => 'İlk mesaj!',
    'restored' => 'Konu geri alındı|Konular geri alındı',
    'thread' => 'Konu|Konular',
    'updated' => 'Konu güncellendi|Konular güncellendi',
    'unlock' => 'Kilidi aç',
    'unpin' => 'Sabitlikten Kaldır',
    'view' => 'Konuyu görüntüle',

];
