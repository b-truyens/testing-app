<?php

return [

    'title' => ':label görüntüle',

    'breadcrumb' => 'Görüntüle',

    'form' => [

        'tab' => [
            'label' => 'Görüntüle',
        ],

    ],

];
