<?php

return [

    'title' => 'Pagrindinis puslapis',

];
