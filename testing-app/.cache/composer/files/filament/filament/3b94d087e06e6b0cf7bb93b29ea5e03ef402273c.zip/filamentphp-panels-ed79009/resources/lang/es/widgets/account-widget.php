<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Salir',
        ],

    ],

    'welcome' => 'Bienvenida/o, :user',

];
