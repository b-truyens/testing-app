<?php

return [

    'single' => [

        'label' => '연결 해제',

        'modal' => [

            'heading' => ':label 연결 해제',

            'actions' => [

                'dissociate' => [
                    'label' => '연결 해제',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => '연결 해제됨',
        ],

    ],

    'multiple' => [

        'label' => '선택한 항목 연결 해제',

        'modal' => [

            'heading' => ':label 선택한 항목 연결 해제',

            'actions' => [

                'dissociate' => [
                    'label' => '연결 해제',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => '연결 해제됨',
        ],

    ],

];
