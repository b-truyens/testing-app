<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dokumentācija',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
