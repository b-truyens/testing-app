<?php

return [

    'single' => [

        'label' => 'Dissocia',

        'modal' => [

            'heading' => 'Dissocia :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissocia',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Dissociato',
        ],

    ],

    'multiple' => [

        'label' => 'Dissocia selezionato',

        'modal' => [

            'heading' => 'Dissocia selezionato :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Dissocia selezionato',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Dissociato',
        ],

    ],

];
