<?php

return [

    'title' => 'Zobrazit :label',

    'breadcrumb' => 'Zobrazit',

    'form' => [

        'tab' => [
            'label' => 'Zobrazit',
        ],

    ],

];
