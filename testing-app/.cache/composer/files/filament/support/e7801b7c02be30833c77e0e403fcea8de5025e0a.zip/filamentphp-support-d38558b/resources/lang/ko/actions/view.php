<?php

return [

    'single' => [

        'label' => 'View',

        'modal' => [

            'heading' => 'View :label',

            'actions' => [

                'close' => [
                    'label' => '닫기',
                ],

            ],

        ],

    ],

];
