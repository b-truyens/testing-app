<x-heroicon-s-x
    class="filament-notifications-close-button h-4 w-4 cursor-pointer text-gray-400"
    x-on:click="close"
/>
