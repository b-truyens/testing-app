<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Гарах',
        ],

    ],

    'welcome' => 'Тавтай морилно уу, :user',

];
