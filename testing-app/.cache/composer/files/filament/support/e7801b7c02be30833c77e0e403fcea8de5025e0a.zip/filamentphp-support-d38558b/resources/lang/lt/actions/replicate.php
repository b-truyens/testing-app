<?php

return [

    'single' => [

        'label' => 'Atkartoti',

        'modal' => [

            'heading' => 'Arkartoti :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Arkartoti',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Arkartota',
        ],

    ],

];
