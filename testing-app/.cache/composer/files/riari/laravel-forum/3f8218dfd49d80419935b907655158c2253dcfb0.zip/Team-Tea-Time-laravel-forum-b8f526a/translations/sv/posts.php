<?php

return [

    'actions' => 'Inlägg åtgärder',
    'created' => 'Inlägg som skapas',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Inlägg raderad|Inlägg raderad',
    'edit' => 'Redigera inlägg',
    'last' => 'Senaste inlägg',
    'perma_deleted' => 'Inlägg tas bort permanent|Inlägg tas bort permanent',
    'post' => 'Inlägg|Inlägg',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Inlägg restaurerade|Inlägg restaurerade',
    'select_all' => 'Select all posts',
    'updated' => 'Inlägg uppdaterat|Inlägg uppdaterat',
    'view' => 'Visa inlägg',
    'your_post' => 'Dina inlägg',

];
