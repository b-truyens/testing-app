<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Oturumu kapat',
        ],

    ],

    'welcome' => 'Hoş geldin, :user',

];
