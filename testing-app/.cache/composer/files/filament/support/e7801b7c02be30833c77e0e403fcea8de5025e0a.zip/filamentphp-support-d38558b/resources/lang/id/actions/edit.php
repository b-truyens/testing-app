<?php

return [

    'single' => [

        'label' => 'Ubah',

        'modal' => [

            'heading' => 'Ubah :label',

            'actions' => [

                'save' => [
                    'label' => 'Simpan',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Data berhasil disimpan',
        ],

    ],

];
