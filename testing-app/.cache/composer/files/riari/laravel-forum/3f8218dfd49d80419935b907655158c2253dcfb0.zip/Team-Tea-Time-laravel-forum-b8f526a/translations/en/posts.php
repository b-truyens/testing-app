<?php

return [

    'actions' => 'Post actions',
    'created' => 'Post created',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Post deleted|Posts deleted',
    'edit' => 'Edit post',
    'last' => 'Last post',
    'perma_deleted' => 'Post permanently deleted|Posts permanently deleted',
    'post' => 'Post|Posts',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Post restored|Posts restored',
    'select_all' => 'Select all posts',
    'updated' => 'Post updated|Posts updated',
    'view' => 'View post',
    'your_post' => 'Your post',

];
