<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Tài liệu',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
