<?php

return [
    'title' => 'Crear :label',
    'breadcrumb' => 'Crear',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Cancel·lar',
            ],

            'create' => [
                'label' => 'Crear',
            ],

            'create_another' => [
                'label' => 'Crear & crear un altre',
            ],

        ],

    ],

    'messages' => [
        'created' => 'Creat',
    ],

];
