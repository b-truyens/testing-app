<?php

return [

    'category_threads_enabled' => 'La catégorie doit autoriser la création de nouvelles discussions.',
    'category_has_no_threads' => 'La catégorie ne doit pas contenir de discussions.',
    'category_is_empty' => 'La catégorie doit être vide.',

];
