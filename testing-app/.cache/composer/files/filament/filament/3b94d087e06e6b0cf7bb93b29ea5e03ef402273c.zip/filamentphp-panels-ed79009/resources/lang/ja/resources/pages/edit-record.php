<?php

return [

    'title' => ':label編集',

    'breadcrumb' => '編集',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'キャンセル',
            ],

            'save' => [
                'label' => '保存',
            ],

        ],

        'tab' => [
            'label' => '編集',
        ],

    ],

    'messages' => [
        'saved' => '保存しました',
    ],

];
