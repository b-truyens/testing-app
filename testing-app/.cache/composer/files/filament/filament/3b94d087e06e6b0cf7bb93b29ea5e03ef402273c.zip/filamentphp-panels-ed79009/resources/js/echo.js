import Echo from 'laravel-echo'
import Pusher from 'pusher-js'

window.EchoFactory = Echo
window.Pusher = Pusher
