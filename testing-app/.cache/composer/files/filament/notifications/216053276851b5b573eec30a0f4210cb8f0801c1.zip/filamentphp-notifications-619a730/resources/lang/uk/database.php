<?php

return [

    'modal' => [

        'heading' => 'Сповіщення',

        'buttons' => [

            'clear' => [
                'label' => 'Видалити',
            ],

            'mark_all_as_read' => [
                'label' => 'Позначити як прочитане',
            ],

        ],

        'empty' => [
            'heading' => 'Немає повідомлень',
            'description' => 'Будь ласка, перевірте пізніше',
        ],

    ],

];
