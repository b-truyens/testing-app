<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Documentatie',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
