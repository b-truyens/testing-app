<?php

return [

    'trigger' => [
        'label' => '액션',
    ],

];
