<?php

return [

    'single' => [

        'label' => 'Изменить',

        'modal' => [

            'heading' => 'Изменить :label',

            'actions' => [

                'save' => [
                    'label' => 'Сохранить',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Сохранено',
        ],

    ],

];
