<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Kijelentkezés',
        ],

    ],

    'welcome' => 'Üdv, :user',

];
