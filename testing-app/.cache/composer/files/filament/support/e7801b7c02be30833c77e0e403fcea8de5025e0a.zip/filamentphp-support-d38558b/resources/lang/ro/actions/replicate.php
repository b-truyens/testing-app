<?php

return [

    'single' => [

        'label' => 'Replicare',

        'modal' => [

            'heading' => 'Replicare :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Replicare',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Replicat cu succes',
        ],

    ],

];
