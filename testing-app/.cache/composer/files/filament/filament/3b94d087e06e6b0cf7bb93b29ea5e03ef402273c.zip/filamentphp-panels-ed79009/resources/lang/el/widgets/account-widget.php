<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Αποσύνδεση',
        ],

    ],

    'welcome' => 'Καλώς ήρθες, :user',

];
