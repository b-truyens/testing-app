<?php

return [

    'breadcrumb' => 'Sąrašas',

];
