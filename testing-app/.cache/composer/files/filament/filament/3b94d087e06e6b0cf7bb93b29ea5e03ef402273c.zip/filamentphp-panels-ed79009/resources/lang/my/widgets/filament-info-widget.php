<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'အညွန်း',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
