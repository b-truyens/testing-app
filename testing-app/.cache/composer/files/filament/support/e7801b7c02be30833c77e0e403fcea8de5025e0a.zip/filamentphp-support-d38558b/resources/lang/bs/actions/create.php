<?php

return [

    'single' => [

        'label' => 'Napraviti',

        'modal' => [

            'heading' => 'Napravite :label',

            'actions' => [

                'create' => [
                    'label' => 'Napraviti',
                ],

                'create_another' => [
                    'label' => 'Napravite i napravite još jedan',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Uspješno kreirano',
        ],

    ],

];
