<?php

return [

    'single' => [

        'label' => 'Ny :label',

        'modal' => [

            'heading' => 'Opret :label',

            'actions' => [

                'create' => [
                    'label' => 'Opret',
                ],

                'create_another' => [
                    'label' => 'Opret og opret en mere',
                ],

            ],

        ],

        'messages' => [
            'created' => 'Oprettet',
        ],

    ],

];
