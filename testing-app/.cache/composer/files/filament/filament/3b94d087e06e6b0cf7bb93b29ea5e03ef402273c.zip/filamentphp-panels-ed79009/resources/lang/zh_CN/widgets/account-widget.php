<?php

return [

    'buttons' => [

        'logout' => [
            'label' => '退出登录',
        ],

    ],

    'welcome' => '欢迎，:user',

];
