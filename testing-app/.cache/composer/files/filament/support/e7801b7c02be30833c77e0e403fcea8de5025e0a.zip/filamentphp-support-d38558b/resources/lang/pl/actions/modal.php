<?php

return [

    'confirmation' => 'Czy na pewno chcesz to zrobić?',

    'actions' => [

        'cancel' => [
            'label' => 'Anuluj',
        ],

        'confirm' => [
            'label' => 'Potwierdź',
        ],

        'submit' => [
            'label' => 'Zatwierdź',
        ],

    ],

];
