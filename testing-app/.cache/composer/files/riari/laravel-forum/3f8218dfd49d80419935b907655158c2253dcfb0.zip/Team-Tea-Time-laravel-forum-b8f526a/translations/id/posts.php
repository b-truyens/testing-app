<?php

return [

    'actions' => 'Aksi pada Postingan',
    'created' => 'Postingan dibuat',
    'delete' => 'Hapus postingan|Hapus postingan',
    'deleted' => 'Postingan dihapus|Postingan dihapus',
    'edit' => 'Ubah postingan',
    'last' => 'Postingan terakhir',
    'perma_deleted' => 'Postingan dihapus secara permanen|Postingan dihapus secara permanen',
    'post' => 'Postingan|Postingan',
    'restore' => 'Pulihkan postingan|Pulihkan postingan',
    'restored' => 'Postingan dipulihkan|Postingan dipulihkan',
    'select_all' => 'Pilih semua postingan',
    'updated' => 'Postingan diperbarui|Postingan diperbarui',
    'view' => 'Lihat postingan',
    'your_post' => 'Postingan Anda',

];
