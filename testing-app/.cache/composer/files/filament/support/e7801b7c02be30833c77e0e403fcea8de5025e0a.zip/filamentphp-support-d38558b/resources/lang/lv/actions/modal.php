<?php

return [

    'confirmation' => 'Vai esi pārliecināts, ka vēlies veikt šo darbību?',

    'actions' => [

        'cancel' => [
            'label' => 'Atcelt',
        ],

        'confirm' => [
            'label' => 'Apstiprināt',
        ],

        'submit' => [
            'label' => 'Iesniegt',
        ],

    ],

];
