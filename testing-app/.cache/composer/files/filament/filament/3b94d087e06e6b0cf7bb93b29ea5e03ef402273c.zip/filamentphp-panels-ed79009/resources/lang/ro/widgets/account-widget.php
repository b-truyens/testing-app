<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Deconectare',
        ],

    ],

    'welcome' => 'Bun venit, :user',

];
