<?php

return [

    'single' => [

        'label' => 'Vedhæft',

        'modal' => [

            'heading' => 'Vedhæft :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Post',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Vedhæft',
                ],

                'attach_another' => [
                    'label' => 'Vedhæft og vedhæft en mere',
                ],

            ],

        ],

        'messages' => [
            'attached' => 'Vedhæftet',
        ],

    ],

];
