<?php

return [

    'single' => [

        'label' => 'Gennemtving sletning',

        'modal' => [

            'heading' => 'Gennemtving sletning af :label',

            'actions' => [

                'delete' => [
                    'label' => 'Slet',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Slettet',
        ],

    ],

    'multiple' => [

        'label' => 'Gennemtving sletning af valgte',

        'modal' => [

            'heading' => 'Gennemtving sletning af valgte :label',

            'actions' => [

                'delete' => [
                    'label' => 'Slet',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Slettet',
        ],

    ],

];
