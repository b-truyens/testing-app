<?php

return [

    'title' => 'Перегляд :label',

    'breadcrumb' => 'Перегляд',

    'form' => [

        'tab' => [
            'label' => 'Перегляд',
        ],

    ],

];
