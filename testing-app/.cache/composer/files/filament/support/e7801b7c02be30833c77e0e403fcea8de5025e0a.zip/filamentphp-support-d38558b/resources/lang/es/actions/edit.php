<?php

return [

    'single' => [

        'label' => 'Editar',

        'modal' => [

            'heading' => 'Editar :label',

            'actions' => [

                'save' => [
                    'label' => 'Guardar cambios',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Guardado',
        ],

    ],

];
