<?php

return [

    'single' => [

        'label' => 'Scollega',

        'modal' => [

            'heading' => 'Scollega :label',

            'actions' => [

                'detach' => [
                    'label' => 'Scollega',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Scollegato',
        ],

    ],

    'multiple' => [

        'label' => 'Scollega selezionato',

        'modal' => [

            'heading' => 'Scollega selezionato :label',

            'actions' => [

                'detach' => [
                    'label' => 'Scollega selezionato',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Scollegato',
        ],

    ],

];
