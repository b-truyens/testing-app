<?php

return [

    'title' => 'Visa :label',

    'breadcrumb' => 'Visa',

    'form' => [

        'tab' => [
            'label' => 'Visa',
        ],

    ],

];
