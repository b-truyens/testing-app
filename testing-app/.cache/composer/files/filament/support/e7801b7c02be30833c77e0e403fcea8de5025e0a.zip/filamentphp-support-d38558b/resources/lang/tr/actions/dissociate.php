<?php

return [

    'single' => [

        'label' => 'Ayrıştır',

        'modal' => [

            'heading' => ':label ayrıştır',

            'actions' => [

                'dissociate' => [
                    'label' => 'Ayrıştır',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Ayrıştırıldı',
        ],

    ],

    'multiple' => [

        'label' => 'Seçiliyi ayrıştır',

        'modal' => [

            'heading' => ':label seçiliyi ayrıştır',

            'actions' => [

                'dissociate' => [
                    'label' => 'Seçiliyi ayrıştır',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Ayrıştırıldı',
        ],

    ],

];
