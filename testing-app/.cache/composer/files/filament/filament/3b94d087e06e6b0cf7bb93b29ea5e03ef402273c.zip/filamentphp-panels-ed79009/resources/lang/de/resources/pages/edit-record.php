<?php

return [

    'title' => ':label bearbeiten',

    'breadcrumb' => 'Bearbeiten',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Abbrechen',
            ],

            'save' => [
                'label' => 'Speichern',
            ],

        ],

        'tab' => [
            'label' => 'Bearbeiten',
        ],

    ],

    'messages' => [
        'saved' => 'Gespeichert',
    ],

];
