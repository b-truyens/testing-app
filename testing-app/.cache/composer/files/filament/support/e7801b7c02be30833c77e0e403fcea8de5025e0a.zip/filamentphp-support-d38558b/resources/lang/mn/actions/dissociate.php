<?php

return [

    'single' => [

        'label' => 'Холбоосыг салгах',

        'modal' => [

            'heading' => 'Салгах :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Салгах',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Салгасан',
        ],

    ],

    'multiple' => [

        'label' => 'Сонгосонг салгах',

        'modal' => [

            'heading' => 'Салгах :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Салгах',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Салгасан',
        ],

    ],

];
