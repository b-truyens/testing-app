<?php

return [

    'title' => 'Редактирование :label',

    'breadcrumb' => 'Редактирование',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Отмена',
            ],

            'save' => [
                'label' => 'Сохранить',
            ],

        ],

        'tab' => [
            'label' => 'Изменить',
        ],

    ],

    'messages' => [
        'saved' => 'Сохранено',
    ],

];
