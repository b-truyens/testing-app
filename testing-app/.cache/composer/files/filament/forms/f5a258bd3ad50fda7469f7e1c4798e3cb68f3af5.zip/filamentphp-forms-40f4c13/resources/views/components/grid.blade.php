<div {{ $attributes->merge($getExtraAttributes()) }}>
    {{ $getChildComponentContainer() }}
</div>
