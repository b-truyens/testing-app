<?php

return [

    'actions' => 'Acțiuni mesaj',
    'created' => 'Mesajul creat',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Mesaj șters|Mesaje șterse',
    'edit' => 'Editează mesaj',
    'last' => 'Ultimul mesaj',
    'perma_deleted' => 'Mesaj șters definitiv|Mesaje șters definitiv',
    'post' => 'Mesaj|Mesaje',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Mesajul restaurat|Mesaje restaurat',
    'select_all' => 'Select all posts',
    'updated' => 'Mesaj actualizat|Mesaje actualizat',
    'view' => 'Vezi mesajul',
    'your_post' => 'Mesajul tău',

];
