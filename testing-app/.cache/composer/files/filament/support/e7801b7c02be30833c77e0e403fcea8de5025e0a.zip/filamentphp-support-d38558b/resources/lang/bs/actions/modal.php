<?php

return [

    'confirmation' => 'Jeste li sigurni da želite to učiniti?',

    'actions' => [

        'cancel' => [
            'label' => 'Prekiniti',
        ],

        'confirm' => [
            'label' => 'Konfirmisati',
        ],

        'submit' => [
            'label' => 'Poslati',
        ],

    ],

];
