<?php

return [

    'single' => [

        'label' => 'گەڕاندنەوە',

        'modal' => [

            'heading' => 'گەڕاندنەوەی :label',

            'actions' => [

                'restore' => [
                    'label' => 'گەڕاندنەوە',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'گەڕێندرایەوە',
        ],

    ],

    'multiple' => [

        'label' => 'دیاریکردنی گەڕاندنەوە',

        'modal' => [

            'heading' => 'دیاریکراوی :label بگەڕێنەرەوە',

            'actions' => [

                'restore' => [
                    'label' => 'گەڕاندنەوە',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'گەڕێندرایەوە',
        ],

    ],

];
