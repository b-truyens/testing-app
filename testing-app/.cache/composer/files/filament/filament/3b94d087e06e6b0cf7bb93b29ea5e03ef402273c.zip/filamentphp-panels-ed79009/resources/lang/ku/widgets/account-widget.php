<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'چوونەدەرەوە',
        ],

    ],

    'welcome' => 'بەخێربێیت، :user',

];
