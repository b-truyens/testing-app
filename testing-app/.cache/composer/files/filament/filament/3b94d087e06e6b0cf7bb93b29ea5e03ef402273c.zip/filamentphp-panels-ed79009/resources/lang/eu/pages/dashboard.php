<?php

return [

    'title' => 'Idazmahai',

];
