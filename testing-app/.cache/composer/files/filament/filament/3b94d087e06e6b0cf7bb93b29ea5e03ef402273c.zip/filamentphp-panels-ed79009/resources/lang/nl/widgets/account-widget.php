<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Uitloggen',
        ],

    ],

    'welcome' => 'Welkom, :user',

];
