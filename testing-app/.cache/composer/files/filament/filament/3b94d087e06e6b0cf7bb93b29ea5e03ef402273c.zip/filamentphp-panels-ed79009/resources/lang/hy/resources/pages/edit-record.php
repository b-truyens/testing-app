<?php

return [

    'title' => 'Խմբագրել :label',

    'breadcrumb' => 'Խմբագրել',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Չեղարկել',
            ],

            'save' => [
                'label' => 'Պահպանել',
            ],

        ],

    ],

    'messages' => [
        'saved' => 'Պահպանված է',
    ],

];
