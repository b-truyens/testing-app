<?php

return [

    'title' => 'Editar :label',

    'breadcrumb' => 'Editar',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Cancel·lar',
            ],

            'save' => [
                'label' => 'Guardar',
            ],

        ],

        'tab' => [
            'label' => 'Editar',
        ],

    ],

    'messages' => [
        'saved' => 'Guardat',
    ],

];
