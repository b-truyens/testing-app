<?php

return [

    'single' => [

        'label' => 'Iga',

        'modal' => [

            'heading' => 'Iga :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Iga',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Imeigwa',
        ],

    ],

];
