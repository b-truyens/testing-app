<?php

return [

    'title' => 'Sunting :label',

    'breadcrumb' => 'Sunting',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Batal',
            ],

            'save' => [
                'label' => 'Simpan',
            ],

        ],

        'tab' => [
            'label' => 'Sunting',
        ],

    ],

    'messages' => [
        'saved' => 'Disimpan',
    ],

];
