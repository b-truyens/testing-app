<?php

return [

    'single' => [

        'label' => 'Eliminar',

        'modal' => [

            'heading' => 'Eliminar :label',

            'actions' => [

                'delete' => [
                    'label' => 'Eliminar',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Eliminat',
        ],

    ],

    'multiple' => [

        'label' => 'Eliminar seleccionats',

        'modal' => [

            'heading' => 'Eliminar :label seleccionat',

            'actions' => [

                'delete' => [
                    'label' => 'Eliminar',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Eliminat',
        ],

    ],

];
