<?php

return [

    'single' => [

        'label' => 'Duplikat data',

        'modal' => [

            'heading' => 'Duplikat :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplikat data',
                ],

            ],

        ],

        'messages' => [
            'replicated' => 'Data berhasil diduplikat',
        ],

    ],

];
