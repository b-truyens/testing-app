<?php

return [

    'single' => [

        'label' => 'Tanggalkan',

        'modal' => [

            'heading' => 'Tanggalkan :label',

            'actions' => [

                'detach' => [
                    'label' => 'Tanggalkan',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Ditanggalkan',
        ],

    ],

    'multiple' => [

        'label' => 'Tanggalkan pilihan',

        'modal' => [

            'heading' => 'Tanggalkan pilihan :label',

            'actions' => [

                'detach' => [
                    'label' => 'Tanggalkan pilihan',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Ditanggalkan',
        ],

    ],

];
