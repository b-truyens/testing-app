<?php

return [

    'single' => [

        'label' => 'Bista',

        'modal' => [

            'heading' => 'Bista :label',

            'actions' => [

                'close' => [
                    'label' => 'Itxi',
                ],

            ],

        ],

    ],

];
