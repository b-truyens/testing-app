<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Log keluar',
        ],

    ],

    'welcome' => 'Selamat datang, :user',

];
