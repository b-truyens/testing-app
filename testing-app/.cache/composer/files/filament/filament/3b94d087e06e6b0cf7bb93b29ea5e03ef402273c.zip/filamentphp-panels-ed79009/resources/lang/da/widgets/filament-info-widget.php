<?php

return [

    'buttons' => [

        'visit_documentation' => [
            'label' => 'Dokumentation',
        ],

        'visit_github' => [
            'label' => 'GitHub',
        ],

    ],

];
