<?php

return [

    'single' => [

        'label' => 'Ayır',

        'modal' => [

            'heading' => ':label ayır',

            'actions' => [

                'detach' => [
                    'label' => 'Ayır',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Ayrıldı',
        ],

    ],

    'multiple' => [

        'label' => 'Seçiliyi ayır',

        'modal' => [

            'heading' => ':label seçiliyi ayır ',

            'actions' => [

                'detach' => [
                    'label' => 'Seçiliyi ayır',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Ayrıldı',
        ],

    ],

];
