<?php

return [

    'category_threads_enabled' => 'De categorie moet onderwerpen ingeschakeld hebben.',
    'category_has_no_threads' => 'De categorie moet geen onderwerpen bevatten.',
    'category_is_empty' => 'De categorie moet leeg zijn.',

];
