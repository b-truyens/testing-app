<?php

namespace Filament\Tables\Actions\Modal\Actions;

/**
 * @deprecated Use `\Filament\Tables\Actions\Modal\Actions\Action` instead.
 * @see Action
 */
class ButtonAction extends Action
{
}
