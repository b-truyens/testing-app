<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Abmelden',
        ],

    ],

    'welcome' => 'Willkommen, :user',

];
