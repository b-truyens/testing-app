<?php

return [

    'title' => 'ویرایش :label',

    'breadcrumb' => 'ویرایش',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'لغو',
            ],

            'save' => [
                'label' => 'ذخیره',
            ],

        ],

        'tab' => [
            'label' => 'ویرایش',
        ],

    ],

    'messages' => [
        'saved' => 'ذخیره شد',
    ],

];
