<?php

return [

    'single' => [

        'label' => 'တည်းဖြတ်ပါ',

        'modal' => [

            'heading' => ':label ကိုတည်းဖြတ်ပါ',

            'actions' => [

                'save' => [
                    'label' => 'မှတ်ပါ',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'သိမ်းဆည်းပြီး',
        ],

    ],

];
