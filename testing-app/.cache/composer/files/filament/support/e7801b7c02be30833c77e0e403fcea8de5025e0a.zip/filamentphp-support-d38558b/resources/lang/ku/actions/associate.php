<?php

return [

    'single' => [

        'label' => 'هاوکار',

        'modal' => [

            'heading' => 'هاوکار کردنی :label',

            'fields' => [

                'record_id' => [
                    'label' => 'تۆمار',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'هاوکار',
                ],

                'associate_another' => [
                    'label' => 'هاوکار و دانەیەکی تر',
                ],

            ],

        ],

        'messages' => [
            'associated' => 'هاوکار کرا',
        ],

    ],

];
