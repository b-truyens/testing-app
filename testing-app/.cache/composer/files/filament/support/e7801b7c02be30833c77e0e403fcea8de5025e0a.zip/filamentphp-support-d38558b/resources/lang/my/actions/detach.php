<?php

return [

    'single' => [

        'label' => 'ခွဲထုတ်ပါ',

        'modal' => [

            'heading' => ':label ခွဲထုတ်ပါ။',

            'actions' => [

                'detach' => [
                    'label' => 'ခွဲထုတ်ပါ',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'သိမ်းဆည်းပြီး',
        ],

    ],

    'multiple' => [

        'label' => 'Detach selected',

        'modal' => [

            'heading' => 'Detach selected :label',

            'actions' => [

                'detach' => [
                    'label' => 'Detach selected',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Detached',
        ],

    ],

];
