<?php

return [

    'single' => [

        'label' => 'سڕینەوە',

        'modal' => [

            'heading' => 'سڕینەوەی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'سڕدرایەوە',
        ],

    ],

    'multiple' => [

        'label' => 'دیاریکراوەکان بسڕەوە',

        'modal' => [

            'heading' => 'دیاریکراوەکانی :label بسڕەوە',

            'actions' => [

                'delete' => [
                    'label' => 'دیاریکراوەکان بسڕەوە',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'سڕدرایەوە',
        ],

    ],

];
