<?php

return [

    'title' => ':label szerkesztése',

    'breadcrumb' => 'Szerkeszt',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Mégsem',
            ],

            'save' => [
                'label' => 'Mentés',
            ],

        ],

        'tab' => [
            'label' => 'Szerkesztés',
        ],

    ],

    'messages' => [
        'saved' => 'Mentve',
    ],

];
