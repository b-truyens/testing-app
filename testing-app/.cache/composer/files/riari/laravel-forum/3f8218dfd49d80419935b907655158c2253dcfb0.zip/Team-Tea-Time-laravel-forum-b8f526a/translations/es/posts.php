<?php

return [

    'actions' => 'Acciones de Publicación',
    'created' => 'Publicación creado',
    'delete' => 'Delete post|Delete posts',
    'deleted' => 'Publicación eliminada|Publicaciones eliminada',
    'edit' => 'Editar publicación',
    'last' => 'Última publicación',
    'perma_deleted' => 'Publicación eliminará de forma permanente|Publicaciones eliminarán de forma permanente',
    'post' => 'Publicación|Publicaciones',
    'restore' => 'Restore post|Restore posts',
    'restored' => 'Publicación restauradas|Publicaciones restauradas',
    'select_all' => 'Select all posts',
    'updated' => 'Publicación actualizada|Publicaciones actualizada',
    'view' => 'Ver publicación',
    'your_post' => 'Su publicación',

];
