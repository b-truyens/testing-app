<?php

return [

    'single' => [

        'label' => 'Dzēst',

        'modal' => [

            'heading' => 'Dzēst :label',

            'actions' => [

                'delete' => [
                    'label' => 'Dzēst',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Dzēsts',
        ],

    ],

    'multiple' => [

        'label' => 'Dzēst atzīmētos',

        'modal' => [

            'heading' => 'Dzēst atzīmēto :label',

            'actions' => [

                'delete' => [
                    'label' => 'Dzēst',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Dzēsti',
        ],

    ],

];
