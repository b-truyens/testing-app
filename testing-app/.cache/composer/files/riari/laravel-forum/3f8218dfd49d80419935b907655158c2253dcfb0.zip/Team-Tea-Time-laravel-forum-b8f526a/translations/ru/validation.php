<?php

return [

    'category_threads_enabled' => 'Указанная категория должна иметь активные темы.',
    'category_has_no_threads' => 'Категория не должна содержать тем.',
    'category_is_empty' => 'Категория должна быть пустой.',

];
