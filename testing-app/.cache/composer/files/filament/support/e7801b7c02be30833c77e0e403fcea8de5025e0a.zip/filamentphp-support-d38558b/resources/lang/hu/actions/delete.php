<?php

return [

    'single' => [

        'label' => 'Törlés',

        'modal' => [

            'heading' => ':label törlése',

            'actions' => [

                'delete' => [
                    'label' => 'Törlés',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Törölve',
        ],

    ],

    'multiple' => [

        'label' => 'Kiválasztottak törlése',

        'modal' => [

            'heading' => 'Kiválasztott :label törlése',

            'actions' => [

                'delete' => [
                    'label' => 'Törlés',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Törölve',
        ],

    ],

];
