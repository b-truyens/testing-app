<?php

return [

    'buttons' => [

        'logout' => [
            'label' => 'Logout',
        ],

    ],

    'welcome' => 'Bem-vindo, :user',

];
