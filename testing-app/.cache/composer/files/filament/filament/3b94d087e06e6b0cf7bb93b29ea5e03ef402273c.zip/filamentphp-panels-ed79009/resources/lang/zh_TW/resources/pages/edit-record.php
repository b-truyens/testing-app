<?php

return [

    'title' => '編輯 :label',

    'breadcrumb' => '編輯',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => '取消',
            ],

            'save' => [
                'label' => '保存',
            ],

        ],

    ],

    'messages' => [
        'saved' => '已保存',
    ],

];
