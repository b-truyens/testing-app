<?php

return [

    'single' => [

        'label' => 'Տարանջատել',

        'modal' => [

            'heading' => 'Տարանջատել :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Տարանջատել',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Տարանջատվել է',
        ],

    ],

    'multiple' => [

        'label' => 'Տարանջատել ընտրվածը',

        'modal' => [

            'heading' => 'Տարանջատել ընտրված :label',

            'actions' => [

                'dissociate' => [
                    'label' => 'Տարանջատել ընտրվածը',
                ],

            ],

        ],

        'messages' => [
            'dissociated' => 'Տարանջատվել է',
        ],

    ],

];
