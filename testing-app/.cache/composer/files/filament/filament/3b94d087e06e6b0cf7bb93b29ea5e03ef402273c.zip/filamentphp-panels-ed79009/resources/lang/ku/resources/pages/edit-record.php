<?php

return [

    'title' => 'دەستکاری :label',

    'breadcrumb' => 'دەستکاری',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'ڕەتکردنەوە',
            ],

            'save' => [
                'label' => 'هەڵگرتن',
            ],

        ],

        'tab' => [
            'label' => 'دەستکاری',
        ],

    ],

    'messages' => [
        'saved' => 'هەڵگیرا',
    ],

];
