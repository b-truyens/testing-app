<?php

return [

    'title' => 'Tableau de bord',

];
