<?php

return [

    'single' => [

        'label' => 'Atjaunot',

        'modal' => [

            'heading' => 'Atjaunot :label',

            'actions' => [

                'restore' => [
                    'label' => 'Atjaunot',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Atjaunots',
        ],

    ],

    'multiple' => [

        'label' => 'Atjaunot atzīmētos',

        'modal' => [

            'heading' => 'Atjaunot atzīmēto :label',

            'actions' => [

                'restore' => [
                    'label' => 'Atjaunot',
                ],

            ],

        ],

        'messages' => [
            'restored' => 'Atjaunoti',
        ],

    ],

];
