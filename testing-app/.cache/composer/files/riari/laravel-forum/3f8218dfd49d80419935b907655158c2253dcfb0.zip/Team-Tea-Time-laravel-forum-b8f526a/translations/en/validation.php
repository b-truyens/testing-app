<?php

return [

    'category_threads_enabled' => 'The category must have threads enabled.',
    'category_has_no_threads' => 'The category must not contain threads.',
    'category_is_empty' => 'The category must be empty.',

];
