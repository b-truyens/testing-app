<?php

return [

    'single' => [

        'label' => 'Modifier',

        'modal' => [

            'heading' => 'Modifier :label',

            'actions' => [

                'save' => [
                    'label' => 'Sauvegarder',
                ],

            ],

        ],

        'messages' => [
            'saved' => 'Sauvegardé(e)',
        ],

    ],

];
