<?php

return [

    'single' => [

        'label' => 'Izbrišite',

        'modal' => [

            'heading' => 'Brisanje :label',

            'actions' => [

                'delete' => [
                    'label' => 'Izbrišiti',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Izbrisano',
        ],

    ],

    'multiple' => [

        'label' => 'Izbrišite izabrani',

        'modal' => [

            'heading' => 'Izbriši izabrani :label ',

            'actions' => [

                'delete' => [
                    'label' => 'Izbriši izabrani',
                ],

            ],

        ],

        'messages' => [
            'deleted' => 'Izbrisano',
        ],

    ],

];
