<?php

return [

    'direction' => 'ဘယ်မှညာ',

    'buttons' => [

        'dark_mode' => [
            'label' => 'အနက်နောက်ခံပုံစံ',
        ],

        'light_mode' => [
            'label' => 'အဖြူနောက်ခံပုံစံ',
        ],

        'logout' => [
            'label' => 'ထွက်မည်',
        ],

        'user_menu' => [
            'label' => 'အသုံးပြုသူမီနူး',
        ],

    ],

];
