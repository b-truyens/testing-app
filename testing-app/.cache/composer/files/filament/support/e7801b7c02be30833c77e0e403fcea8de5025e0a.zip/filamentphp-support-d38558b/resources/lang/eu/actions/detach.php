<?php

return [

    'single' => [

        'label' => 'Bereizi',

        'modal' => [

            'heading' => 'Bereizi :label',

            'actions' => [

                'detach' => [
                    'label' => 'Bereizi',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Bereizita',
        ],

    ],

    'multiple' => [

        'label' => 'Hautatutakoak bereizi',

        'modal' => [

            'heading' => 'Bereizi :label hautatutakoak',

            'actions' => [

                'detach' => [
                    'label' => 'Bereizi hautatutakoak',
                ],

            ],

        ],

        'messages' => [
            'detached' => 'Bereizita',
        ],

    ],

];
